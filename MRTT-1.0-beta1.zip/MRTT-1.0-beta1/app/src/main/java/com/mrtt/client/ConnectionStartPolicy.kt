package com.mrtt.client

internal enum class ConnectionStartBlocker(val message: String) {
    NoProfile("не выбран профиль: выберите его во вкладке «Профили»"),
    Link("нужна корректная ссылка MRTT"),
    Server("не указан корректный адрес сервера"),
    Port("указан некорректный порт сервера"),
    Password("не указан пароль подключения"),
    StoredSecret("не удалось прочитать сохранённый пароль подключения; введите его заново"),
    Hashes("нет действующих VK хешей или VK токена"),
}

internal object ConnectionStartPolicy {
    fun hasReadyVkCredentials(
        linkMode: Boolean,
        linkHashCount: Int,
        linkTokenPresent: Boolean,
        autoHashMode: Boolean,
        storedTokenPresent: Boolean,
        manualHashCount: Int,
    ): Boolean = when {
        linkMode -> linkHashCount > 0 || linkTokenPresent || manualHashCount > 0 ||
            (autoHashMode && storedTokenPresent)
        autoHashMode -> storedTokenPresent
        else -> manualHashCount > 0
    }

    fun blocker(
        linkMode: Boolean,
        linkValid: Boolean,
        peerValid: Boolean,
        peerPortValid: Boolean,
        connectionPasswordSet: Boolean,
        connectionPasswordReadable: Boolean = true,
        hashesReady: Boolean,
        profileActive: Boolean = true,
    ): ConnectionStartBlocker? {
        if (!profileActive) return ConnectionStartBlocker.NoProfile
        if (!hashesReady) return ConnectionStartBlocker.Hashes
        if (linkMode) return if (linkValid) null else ConnectionStartBlocker.Link
        if (!peerValid) return ConnectionStartBlocker.Server
        if (!peerPortValid) return ConnectionStartBlocker.Port
        return null
    }
}
