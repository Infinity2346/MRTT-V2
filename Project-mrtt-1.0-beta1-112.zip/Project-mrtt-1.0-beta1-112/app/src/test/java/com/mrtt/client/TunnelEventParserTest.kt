package com.mrtt.client

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TunnelEventParserTest {
    @Test
    fun parsesStats() {
        val event = TunnelEventParser.parse(
            "__MRTT_EVENT__|STATS|{\"active\":3,\"bytes_up\":120,\"bytes_down\":450}"
        ) as TunnelEventParser.Event.Stats

        assertEquals(3, event.active)
        assertEquals(120L, event.bytesUp)
        assertEquals(450L, event.bytesDown)
    }

    @Test
    fun parsesFlowOwnerQuestion() {
        val event = TunnelEventParser.parse(
            "__MRTT_EVENT__|FLOW_OWNER|{\"src\":\"10.66.67.2:41234\",\"dst\":\"93.184.216.34:443\",\"proto\":6}"
        ) as TunnelEventParser.Event.FlowOwner

        assertEquals("10.66.67.2:41234", event.src)
        assertEquals("93.184.216.34:443", event.dst)
        assertEquals(6, event.protocol)
    }

    @Test
    fun flowOwnerWithoutAddressesIsIgnored() {
        assertNull(
            TunnelEventParser.parse("__MRTT_EVENT__|FLOW_OWNER|{\"src\":\"\",\"dst\":\"93.184.216.34:443\",\"proto\":6}")
        )
    }

    @Test
    fun parsesFatalError() {
        val event = TunnelEventParser.parse(
            "__MRTT_EVENT__|ERROR|{\"code\":\"AUTH\",\"message\":\"denied\",\"fatal\":true}"
        ) as TunnelEventParser.Event.Error

        assertEquals("AUTH", event.code)
        assertEquals("denied", event.message)
        assertTrue(event.fatal)
    }

    @Test
    fun parsesWorkers() {
        val event = TunnelEventParser.parse(
            "__MRTT_EVENT__|WORKERS|{\"workers\":36}"
        ) as TunnelEventParser.Event.Workers

        assertEquals(36, event.workers)

        val event4 = TunnelEventParser.parse(
            "__MRTT_EVENT__|WORKERS|{\"workers\":4}"
        ) as TunnelEventParser.Event.Workers

        assertEquals(4, event4.workers)

        val event100 = TunnelEventParser.parse(
            "__MRTT_EVENT__|WORKERS|{\"workers\":100}"
        ) as TunnelEventParser.Event.Workers

        assertEquals(100, event100.workers)

        assertNull(TunnelEventParser.parse("__MRTT_EVENT__|WORKERS|{\"workers\":2}"))
        assertNull(TunnelEventParser.parse("__MRTT_EVENT__|WORKERS|{\"workers\":101}"))
    }

    @Test
    fun rustLifecycleObjectPayloadsMatchKotlinContract() {
        assertTrue(
            TunnelEventParser.parse("__MRTT_EVENT__|READY|{}") is
                TunnelEventParser.Event.Ready
        )
        assertTrue(
            TunnelEventParser.parse("__MRTT_EVENT__|STOPPED|{}") is
                TunnelEventParser.Event.Stopped
        )
        assertTrue(
            TunnelEventParser.parse("__MRTT_EVENT__|ACTIVE_ZERO|{}") is
                TunnelEventParser.Event.ActiveZero
        )
        assertTrue(
            TunnelEventParser.parse("__MRTT_EVENT__|NETWORK_SUSPECT|{}") is
                TunnelEventParser.Event.NetworkSuspect
        )
        assertTrue(
            TunnelEventParser.parse("__MRTT_EVENT__|DTLS|{}") is
                TunnelEventParser.Event.Dtls
        )
    }

    @Test
    fun serverRestartRequiresPanelSource() {
        assertTrue(
            TunnelEventParser.parse(
                "__MRTT_EVENT__|SERVER_RESTART|{\"source\":\"panel\"}",
            ) is TunnelEventParser.Event.ServerRestart,
        )
        assertNull(
            TunnelEventParser.parse(
                "__MRTT_EVENT__|SERVER_RESTART|{\"source\":\"network\"}",
            ),
        )
        assertNull(TunnelEventParser.parse("__MRTT_EVENT__|SERVER_RESTART|{}"))
    }

    @Test
    fun parsesCredentialProgress() {
        val progress = TunnelEventParser.parse(
            "__MRTT_EVENT__|PROGRESS|{\"kind\":\"credentials\"}",
        ) as TunnelEventParser.Event.Progress
        assertEquals("credentials", progress.kind)
    }

    @Test
    fun parsesCallUnavailableWithoutTurningItIntoALogError() {
        val event = TunnelEventParser.parse(
            "__MRTT_EVENT__|CALL_UNAVAILABLE|{\"hash\":\"dead-hash\",\"code\":951}",
        ) as TunnelEventParser.Event.CallUnavailable

        assertEquals("dead-hash", event.hash)
        assertEquals(951, event.code)
        assertNull(TunnelEventParser.parse("__MRTT_EVENT__|CALL_UNAVAILABLE|{\"code\":951}"))
    }

    @Test
    fun parsesAuthExpiredSeparatelyFromADeadCall() {
        // Код 5 («User authorization failed») значит «токен мёртв», а не «звонок мёртв»:
        // приложение должно обновить токен, а не пересоздавать звонок.
        val event = TunnelEventParser.parse(
            "__MRTT_EVENT__|AUTH_EXPIRED|{\"code\":5}",
        ) as TunnelEventParser.Event.AuthExpired
        assertEquals(5, event.code)
        assertEquals(0, (TunnelEventParser.parse("__MRTT_EVENT__|AUTH_EXPIRED|{}") as TunnelEventParser.Event.AuthExpired).code)
    }

    @Test
    fun maxTokenRejectionIsNotAnExpiredAccountToken() {
        // Отказ MAX приходил как AUTH_EXPIRED: приложение обновляло VK-сессию
        // и вход в VK терялся при каждом переключении MAX → VK.
        assertEquals(
            TunnelEventParser.Event.MaxTokenRejected,
            TunnelEventParser.parse("__MRTT_EVENT__|MAX_TOKEN_REJECTED|{}"),
        )
    }

    @Test
    fun detailedPerfEventsAreIgnored() {
        assertNull(
            TunnelEventParser.parse(
                "__MRTT_EVENT__|PERF_DETAIL|{\"rows\":[{\"name\":\"Crypto/obfs\"}]}",
            ),
        )
    }

    @Test
    fun rejectsUnknownProgressKinds() {
        assertNull(TunnelEventParser.parse("__MRTT_EVENT__|PROGRESS|{\"kind\":\"unknown\"}"))
    }

    @Test
    fun handlesMalformedAndUnknownEvents() {
        assertNull(TunnelEventParser.parse("__MRTT_EVENT__|CAPTCHA_DONE|invalid"))
        assertNull(TunnelEventParser.parse("__MRTT_EVENT__|READY|"))
        assertNull(TunnelEventParser.parse("__MRTT_EVENT__|READY|null"))
        assertNull(TunnelEventParser.parse("regular log line"))
        assertNull(TunnelEventParser.parse("__MRTT_EVENT__|UNKNOWN|{}"))
    }

    @Test
    fun malformedProtocolLineCannotForgeReadyStoppedOrFatalEvents() {
        for (type in listOf("READY", "STOPPED", "ERROR", "STATS")) {
            for (payload in listOf("", "null", "[]", "{", "garbage", "\u0000")) {
                assertNull(TunnelEventParser.parse("__MRTT_EVENT__|$type|$payload"))
            }
        }
    }

    @Test
    fun negativeStatsAreClampedBeforeLifecycleConsumption() {
        val event = TunnelEventParser.parse(
            "__MRTT_EVENT__|STATS|{\"active\":-9,\"bytes_up\":-1,\"bytes_down\":-2}",
        ) as TunnelEventParser.Event.Stats

        assertEquals(0, event.active)
        assertEquals(0L, event.bytesUp)
        assertEquals(0L, event.bytesDown)
    }

    @Test
    fun deterministicProtocolPipeChaosNeverThrowsOrCreatesNegativeState() {
        val cases = System.getenv("MRTT_ANDROID_PARSER_CASES")
            ?.toIntOrNull()
            ?.coerceAtLeast(1)
            ?: 50_000
        var random = (System.getenv("MRTT_SOAK_SEED")?.toLongOrNull() ?: 104_729L) xor
            0x6a09e667f3bcc909L
        val types = arrayOf("READY", "STOPPED", "ERROR", "STATS", "CONFIG", "CAPTCHA_DONE", "UNKNOWN")
        val covered = BooleanArray(4)
        repeat(cases) { index ->
            random = nextRandom(random)
            val payload = if (index % 16 == 0) {
                covered[2] = true
                "{\"active\":${random.toInt()},\"bytes_up\":${random shr 1},\"bytes_down\":${random shr 2}}"
            } else {
                covered[3] = true
                buildString(((random ushr 8) % 128).toInt()) {
                    var value = random
                    repeat(((random ushr 8) % 128).toInt()) {
                        value = nextRandom(value)
                        append(((value ushr 16) and 0x7f).toInt().toChar())
                    }
                }
            }
            val line = if (index % 3 == 0) {
                covered[0] = true
                "__MRTT_EVENT__|${types[index % types.size]}|$payload"
            } else {
                covered[1] = true
                payload
            }
            val event = TunnelEventParser.parse(line)
            if (event is TunnelEventParser.Event.Stats) {
                assertTrue(event.active >= 0)
                assertTrue(event.bytesUp >= 0)
                assertTrue(event.bytesDown >= 0)
            }
        }
        assertTrue(covered.all { it })
    }

    private fun nextRandom(value: Long): Long {
        var next = value
        next = next xor (next shl 13)
        next = next xor (next ushr 7)
        next = next xor (next shl 17)
        return next
    }
}
