package com.mrtt.client.ui.utils

import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class MrttLink(
    val host: String,
    val port: Int,
    val password: String = "",
    val hashes: List<String> = emptyList(),
    val vkAccessToken: String = "",
    val maxGroupId: String = "",
    val jitsiRoom: String = "",
    val jitsiSeats: Int = 0,
    val transport: String = "",
)

private const val MRTT_CIPHER_KEY_SEED = "mrtt-chiper-key"

private val cipherKey: SecretKeySpec by lazy {
    val digest = MessageDigest.getInstance("SHA-256")
    val keyBytes = digest.digest(MRTT_CIPHER_KEY_SEED.toByteArray(Charsets.UTF_8))
    SecretKeySpec(keyBytes, "AES")
}

fun decodeBase64Safe(input: String): ByteArray? {
    val clean = input.replace("\n", "").replace("\r", "").replace(" ", "").trim()
    return runCatching {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            runCatching { java.util.Base64.getUrlDecoder().decode(clean) }
                .getOrElse { java.util.Base64.getDecoder().decode(clean) }
        } else {
            android.util.Base64.decode(clean, android.util.Base64.DEFAULT or android.util.Base64.URL_SAFE)
        }
    }.recoverCatching {
        runCatching { java.util.Base64.getUrlDecoder().decode(clean) }
            .getOrElse { java.util.Base64.getDecoder().decode(clean) }
    }.getOrNull()
}

fun decryptMrttPayload(rawPayload: String): String? {
    val bytes = decodeBase64Safe(rawPayload) ?: return null
    if (bytes.size >= 28) {
        val decrypted = runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val spec = GCMParameterSpec(128, bytes, 0, 12)
            cipher.init(Cipher.DECRYPT_MODE, cipherKey, spec)
            val plaintext = cipher.doFinal(bytes, 12, bytes.size - 12)
            String(plaintext, Charsets.UTF_8)
        }.getOrNull()
        if (decrypted != null) {
            return decrypted
        }
    }
    return null
}

fun encryptMrttPayload(plaintext: String): String {
    val iv = runCatching {
        val mac = javax.crypto.Mac.getInstance("HmacSHA256")
        mac.init(cipherKey)
        val hmacBytes = mac.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        ByteArray(12).apply { System.arraycopy(hmacBytes, 0, this, 0, 12) }
    }.getOrElse {
        ByteArray(12).apply { java.security.SecureRandom().nextBytes(this) }
    }
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    val spec = GCMParameterSpec(128, iv)
    cipher.init(Cipher.ENCRYPT_MODE, cipherKey, spec)
    val ciphertextAndTag = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
    val combined = ByteArray(12 + ciphertextAndTag.size)
    System.arraycopy(iv, 0, combined, 0, 12)
    System.arraycopy(ciphertextAndTag, 0, combined, 12, ciphertextAndTag.size)
    return runCatching {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(combined)
        } else {
            android.util.Base64.encodeToString(
                combined,
                android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP
            ).trim()
        }
    }.recoverCatching {
        java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(combined)
    }.getOrElse { "" }
}

const val MRTT_LINK_SCHEME = "mrtt://"

fun parseMrttLink(raw: String): MrttLink? {
    val trimmed = raw.trim()
    if (!trimmed.startsWith(MRTT_LINK_SCHEME, ignoreCase = true)) return null
    val payload = trimmed.substring(MRTT_LINK_SCHEME.length).trim()
    val decoded = decryptMrttPayload(payload) ?: return null
    // Внутри только параметры подключения: вложенные ссылки с любой схемой не принимаются.
    if (decoded.contains("://")) return null
    if (decoded.contains("host=") || decoded.contains("connect?")) {
        val candidate = if (decoded.startsWith("connect?", ignoreCase = true)) {
            "$MRTT_LINK_SCHEME$decoded"
        } else {
            "${MRTT_LINK_SCHEME}connect?$decoded"
        }
        val decodedUri = runCatching { java.net.URI(candidate) }.getOrNull()
        if (decodedUri != null) {
            val parsed = parseMrttV2(decodedUri)
            if (parsed != null) return parsed
        }
    }
    return null
}

fun MrttLink.peerAddress(): String {
    val formattedHost = if (host.contains(':') && !host.startsWith('[')) "[$host]" else host
    return "$formattedHost:$port"
}

private fun parseMrttV2(uri: java.net.URI): MrttLink? {
    if (uri.rawUserInfo != null || uri.port != -1 || uri.rawPath.orEmpty().isNotEmpty()) return null
    val parameters = parseRawQuery(uri.rawQuery ?: return null) ?: return null
    if (parameters["v"]?.let(::decodeQueryComponent) != "2") return null
    val host = parameters["host"]?.let(::decodeQueryComponent)?.takeIf { it.isNotBlank() } ?: return null
    if (host == "0.0.0.0" || host == "127.0.0.1" || host.equals("localhost", ignoreCase = true) || host == "::1") return null
    val port = parameters["peer"]?.let(::decodeQueryComponent)?.toIntOrNull()?.takeIf { it in 1..65535 } ?: return null
    val password = parameters["password"]?.let(::decodeQueryComponent)?.trim().orEmpty()
    if (host.any(Char::isWhitespace) || (password.isNotEmpty() && password.any(Char::isWhitespace))) return null
    val hashes = parameters["hashes"]?.let(::parseLinkHashes) ?: emptyList()
    if (parameters.containsKey("hashes") && hashes.isEmpty()) return null
    val vkAccessToken = parameters["token"]?.let(::parseLinkVkAccessToken).orEmpty()
    if (parameters.containsKey("token") && vkAccessToken.isEmpty()) return null
    if (hashes.isNotEmpty() && vkAccessToken.isNotEmpty()) return null
    val maxGroupId = parameters["max"]?.let(::decodeQueryComponent)?.trim().orEmpty()
    if (parameters.containsKey("max") && !isValidMaxGroupId(maxGroupId)) return null
    if (maxGroupId.isNotEmpty() && (hashes.isNotEmpty() || vkAccessToken.isNotEmpty())) return null
    val jitsiRoom = parameters["jitsi"]?.let(::decodeQueryComponent)?.trim()?.lowercase().orEmpty()
    if (parameters.containsKey("jitsi") && !isValidJitsiRoom(jitsiRoom)) return null
    val jitsiSeats = parameters["seats"]?.let(::decodeQueryComponent)?.toIntOrNull()
        ?.coerceIn(1, com.mrtt.client.MrttConstants.Tunnel.MAX_JITSI_WORKERS) ?: 0
    val transport = parameters["transport"]?.let(::decodeQueryComponent)?.trim()?.lowercase().orEmpty()
        .takeIf { it == com.mrtt.client.MrttConstants.Transport.MODE_VK || it == com.mrtt.client.MrttConstants.Transport.MODE_JITSI }
        .orEmpty()
    return MrttLink(host, port, password, hashes, vkAccessToken, maxGroupId, jitsiRoom, jitsiSeats, transport)
}

private val JITSI_ROOM_REGEX = Regex("^[a-z0-9.:-]+/[a-z0-9]{1,64}$")

fun isValidJitsiRoom(value: String): Boolean = value.matches(JITSI_ROOM_REGEX)

fun parseJitsiRoomInput(raw: String): String? {
    val value = raw.trim().removePrefix("https://").removePrefix("http://")
        .substringBefore('?').substringBefore('#').trimEnd('/').lowercase()
    return value.takeIf(::isValidJitsiRoom)
}

fun isValidMaxGroupId(value: String): Boolean =
    value.length in 1..64 && value.matches(Regex("^-?[0-9]+$"))

private fun parseRawQuery(rawQuery: String): Map<String, String>? {
    if (rawQuery.isEmpty()) return null
    val sanitized = rawQuery.replace("&amp;", "&")
    val result = linkedMapOf<String, String>()
    if (sanitized.contains('&') || sanitized.contains(';')) {
        for (part in sanitized.split(Regex("[&;]"))) {
            if (part.isBlank()) continue
            val separator = part.indexOf('=')
            if (separator <= 0) continue
            val key = decodeQueryComponent(part.substring(0, separator)) ?: continue
            val value = part.substring(separator + 1)
            if (key.isNotBlank()) {
                if (result.containsKey(key)) return null
                result[key] = value
            }
        }
        if (result.isNotEmpty() && result.containsKey("v") && result.containsKey("host") && result.containsKey("peer")) {
            return result
        }
    }

    val pattern = Regex("(?:^|[&;]|(?<=[a-zA-Z0-9_]))(v|host|peer|password|client|hashes|token|max|jitsi|seats|workers|transport)=([^&?]*?)(?=(?:v|host|peer|password|client|hashes|token|max|jitsi|seats|workers|transport)=|$)", RegexOption.IGNORE_CASE)
    val matches = pattern.findAll(sanitized).toList()
    if (matches.isNotEmpty()) {
        val extracted = linkedMapOf<String, String>()
        for (match in matches) {
            val key = decodeQueryComponent(match.groupValues[1].lowercase()) ?: continue
            val value = match.groupValues[2]
            if (extracted.containsKey(key)) return null
            extracted[key] = value
        }
        if (extracted.isNotEmpty() && extracted.containsKey("v") && extracted.containsKey("host") && extracted.containsKey("peer")) {
            return extracted
        }
    }

    return if (result.isNotEmpty()) result else null
}

private fun parseLinkHashes(rawHashes: String): List<String> {
    val parts = rawHashes.split('+')
    if (parts.size !in 1..6 || parts.any { it.isEmpty() }) return emptyList()
    val hashes = parts.map { encoded ->
        decodeQueryComponent(encoded)?.let(::stripVkUrlStatic).orEmpty()
    }
    if (hashes.any { it.length < 16 || it.any(Char::isWhitespace) }) return emptyList()
    return hashes.distinct().takeIf { it.size == hashes.size }.orEmpty()
}

private fun parseLinkVkAccessToken(rawToken: String): String? {
    val token = decodeQueryComponent(rawToken)?.trim().orEmpty()
    return token.takeIf { it.isNotEmpty() && it.length <= 4096 && it.none(Char::isWhitespace) }
}

private fun decodeQueryComponent(value: String): String? {
    return runCatching {
        java.net.URLDecoder.decode(value.replace("+", "%2B"), Charsets.UTF_8.name())
    }.getOrNull()
}

fun stripVkUrlStatic(input: String): String {
    var s = input.trim()
    val lower = s.lowercase()
    val prefixes = listOf(
        "https://vk.com/call/join/",
        "http://vk.com/call/join/",
        "https://m.vk.com/call/join/",
        "http://m.vk.com/call/join/",
        "m.vk.com/call/join/",
        "vk.com/call/join/",
        "https://vk.ru/call/join/",
        "http://vk.ru/call/join/",
        "https://m.vk.ru/call/join/",
        "http://m.vk.ru/call/join/",
        "m.vk.ru/call/join/",
        "vk.ru/call/join/"
    )
    for (prefix in prefixes) {
        if (lower.startsWith(prefix)) {
            s = s.substring(prefix.length)
            break
        }
    }
    val qIdx = s.indexOf('?')
    if (qIdx != -1) s = s.substring(0, qIdx)
    val hIdx = s.indexOf('#')
    if (hIdx != -1) s = s.substring(0, hIdx)
    return s.trimEnd('/')
}

// The server takes the password out of "GETCONF:port|password|…" (split on '|', each field trimmed) and accepts 1..128
// bytes; the rest of the way it is only bytes (HKDF, the TURN digest), so any other character is fine, Cyrillic too.
const val TUNNEL_PASSWORD_MAX_BYTES = 128

fun isValidTunnelPassword(password: String): Boolean =
    password.isNotEmpty() &&
        password.toByteArray(Charsets.UTF_8).size <= TUNNEL_PASSWORD_MAX_BYTES &&
        password.none { it == '|' || it.isWhitespace() || it.isISOControl() }

const val TUNNEL_PASSWORD_RULE = "Без пробелов и «|», не длиннее 128 байт (64 буквы кириллицей)"

fun generate16CharPassword(): String {
    val chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    val random = java.security.SecureRandom()
    val sb = StringBuilder(16)
    for (i in 0 until 16) {
        sb.append(chars[random.nextInt(chars.length)])
    }
    return sb.toString()
}

fun formatMrttLink(
    host: String,
    peer: Int,
    password: String,
    hashes: List<String> = emptyList(),
    token: String = "",
    maxGroupId: String = "",
    jitsiRoom: String = "",
    jitsiSeats: Int = 0,
    transport: String = "",
): String {
    val queryParts = mutableListOf("v=2", "host=$host", "peer=$peer", "password=" + java.net.URLEncoder.encode(password, Charsets.UTF_8.name()))
    if (maxGroupId.isNotEmpty()) {
        require(isValidMaxGroupId(maxGroupId)) { "Некорректный ID группы MAX" }
        queryParts.add("max=$maxGroupId")
    } else if (hashes.isNotEmpty()) {
        queryParts.add("hashes=" + hashes.joinToString("+"))
    } else if (token.isNotEmpty()) {
        queryParts.add("token=$token")
    }
    if (jitsiRoom.isNotEmpty()) {
        require(isValidJitsiRoom(jitsiRoom)) { "Некорректная комната Jitsi" }
        queryParts.add("jitsi=" + java.net.URLEncoder.encode(jitsiRoom, Charsets.UTF_8.name()))
        if (jitsiSeats > 0) queryParts.add("seats=$jitsiSeats")
    }
    if (transport == com.mrtt.client.MrttConstants.Transport.MODE_VK || transport == com.mrtt.client.MrttConstants.Transport.MODE_JITSI) {
        queryParts.add("transport=$transport")
    }
    val plain = "connect?" + queryParts.joinToString("&")
    return MRTT_LINK_SCHEME + encryptMrttPayload(plain)
}

fun MrttLink.format(): String = formatMrttLink(host, port, password, hashes, vkAccessToken, maxGroupId, jitsiRoom, jitsiSeats, transport)
