package com.mrtt.client

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.net.HttpURLConnection
import java.net.URL

private const val TUNNEL_NOTIFICATION_CHANNEL_ID = MrttConstants.Notifications.TUNNEL_CHANNEL_ID
private const val TUNNEL_NOTIFICATION_ID = MrttConstants.Notifications.TUNNEL_NOTIFICATION_ID
private const val NOTIFICATION_MIN_REBUILD_INTERVAL_MS = 5_000L
private const val NETWORK_SWAP_SETTLE_MS = 4_000L
private const val NETWORK_LOSS_GRACE_MS = 2_000L
// Network callbacks drive the Wi-Fi auto-pause; this poll is only a safety net. The pause now lasts as long as the
// phone stays on Wi-Fi (hours), so a 1 s poll woke the app every second for all of it.
private const val AUTO_PAUSE_WIFI_RECONCILE_MS = 15_000L
private const val WAKE_LOCK_TIMEOUT_MS = 10 * 60 * 1_000L
private const val WAKE_LOCK_RENEWAL_WINDOW_MS = 60 * 1_000L
private const val VK_PROBE_CONNECT_TIMEOUT_MS = 3_000
private const val VK_PROBE_READ_TIMEOUT_MS = 3_000
private val VK_PROBE_URLS = listOf(
    "https://login.vk.ru/",
    "https://api.vk.com/",
    "https://vk.ru/",
)
private val MAX_PROBE_URLS = listOf(
    "https://web.max.ru/",
    "https://calls.okcdn.ru/",
)


private data class ResolvedVkHashes(
    val value: String,
    val allowWorkerRedistribution: Boolean,
    val mode: String = MrttConstants.VkAutoHash.MODE_MANUAL,
    val accessToken: String = "",
)

class TunnelService : Service() {
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(serviceJob + Dispatchers.Default)

    private var wakeLock: PowerManager.WakeLock? = null
    private var wakeLockExpiresAtElapsedMs = 0L
    private var wifiLock: WifiManager.WifiLock? = null
    private var updateJob: Job? = null
    private var startJob: Job? = null
    @Volatile
    private var startGeneration = 0L
    private var lastNotificationText: String? = null
    private var lastNotificationPostElapsedMs = 0L
    @Volatile
    private var isStopping = false
    @Volatile
    private var resourcesReleased = false
    private var foregroundStarted = false
    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var airplaneModeReceiver: BroadcastReceiver? = null
    private var networkSwapJob: Job? = null
    private var networkLossJob: Job? = null
    private val physicalNetworks = PhysicalNetworkTracker<Network>()
    private val physicalCandidates = mutableSetOf<Network>()
    private val vkProbeJobs = mutableMapOf<Network, Job>()
    private val vkProbeLock = Any()
    private var vkRecoveryJob: Job? = null
    private var autoPauseSettingsJob: Job? = null
    private var autoPauseWifiWatchJob: Job? = null
    private var domainRoutingSettingsJob: Job? = null
    private val autoPauseMutex = Mutex()
    private val wifiNetworkLock = Any()
    private val physicalWifiNetworks = mutableSetOf<Network>()
    @Volatile
    private var autoPauseOnWifiEnabled = false
    @Volatile
    private var autoPauseRequested = false
    @Volatile
    private var autoPausedForWifi = false
    // «Экономия батареи»: the setting, and the charge as the sticky battery broadcast last said (main thread)
    @Volatile
    private var batterySaverMode = BatterySaver.DEFAULT_MODE
    // nothing is decided before the stored mode is read: the sticky battery broadcast arrives at once, and the default
    // («Авто») could let go of the locks for a moment under a user's «Выкл»
    @Volatile
    private var batterySaverLoaded = false
    @Volatile
    private var batterySaverPercent = BatterySaver.DEFAULT_PERCENT
    private var batteryLevel = -1
    private var batteryCharging = false
    private var systemPowerSave = false
    private var batteryReceiver: BroadcastReceiver? = null
    private var batterySaverJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        TunnelManager.activeScope = serviceScope
        createNotificationChannel()

        acquireWakeLock()
        connectivityManager = getSystemService(ConnectivityManager::class.java)
        registerAirplaneModeReceiver()
        registerPhysicalNetworkCallback()
        observeAutoPauseOnWifi()
        observeDomainRoutingSettings()
        observeBatterySaver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            return if (restoreTunnel()) START_STICKY else START_NOT_STICKY
        }

        when (intent.action) {
            "START" -> {
                if (isStopping) return START_NOT_STICKY
                isStopping = false
                resourcesReleased = false
                startJob?.cancel()
                val requestGeneration = ++startGeneration
                autoPauseRequested = true
                TunnelManager.starting.value = true
                val notification = createNotification("Запуск...")
                if (!tryStartPersistentForeground(notification, "запуск VPN")) {
                    TunnelManager.starting.value = false
                    stopSelf()
                    return START_NOT_STICKY
                }

                val intentGenId = intent.getLongExtra("generation_id", 0L)
                val intentSalt = intent.getStringExtra("session_salt") ?: ""

                startJob = serviceScope.launch {
                    try {
                        val store = SettingsStore(applicationContext)
                        autoPauseOnWifiEnabled = store.autoPauseOnWifi.first()
                        TunnelManager.isLoggingEnabled = store.loggingEnabled.first()
                        if (reconcileWifiAutoPause()) {
                            TunnelManager.starting.value = false
                            return@launch
                        }
                        if (!isCurrentStart(requestGeneration)) return@launch
                        val genId = store.reserveConnectionGeneration(intentGenId)
                        val salt = if (intentSalt.isNotBlank() && genId == intentGenId) {
                            intentSalt
                        } else {
                            newTunnelSessionId()
                        }

                        val requestedWorkers = intent.getIntExtra("workers_per_hash", MrttConstants.Tunnel.DEFAULT_WORKERS)
                        val requestedVkAuthMode = sanitizeVkAuthMode(intent.getStringExtra("vk_auth_mode"))
                        val intentHashes = intent.getStringExtra("vk_hashes") ?: ""
                        val maxGroupId = intent.getStringExtra("max_group_id").orEmpty()
                        val jitsiRoom = intent.getStringExtra("jitsi_room").orEmpty()
                        // Проверки сети и хешей VK нужны только транспорту VK
                        val vkTransport = maxGroupId.isBlank() && jitsiRoom.isBlank()
                        val maxAccessToken = store.maxAccessToken.first()
                        val maxDeviceId = store.maxDeviceId.first()
                        val hashesFromLink = intent.getBooleanExtra("vk_hashes_from_link", false)
                        val linkAccessToken = intent.getStringExtra("vk_access_token")
                            .orEmpty()
                            .takeIf { intent.getBooleanExtra("vk_token_from_link", false) && it.isNotBlank() }
                        // Выбранный пользователем режим не переписываем: он лишь говорит,
                        // откуда брать креды — из своего входа в VK или из ссылки сервера.
                        val credentialPlan = planVkCredentials(
                            requestedAuthMode = requestedVkAuthMode,
                            hashesFromLink = hashesFromLink,
                            linkTokenPresent = linkAccessToken != null,
                            ownVkSessionBound = store.hasAnyVkBinding(),
                            preferLinkVk = store.vkPreferLinkHashes.first(),
                        )
                        val vkAuthMode = credentialPlan.authMode
                        val maxWorkers = MrttConstants.Tunnel.MAX_WORKERS
                        val workersPerHash = WorkerCountPolicy.normalize(requestedWorkers, maximum = maxWorkers)
                        TunnelManager.isLoggingEnabled = store.loggingEnabled.first()
                        if (vkTransport && !awaitVkNetwork()) {
                            TunnelManager.starting.value = false
                            return@launch
                        }
                        if (!isCurrentStart(requestGeneration)) return@launch
                        // Токен из ссылки нужен и тогда, когда режим — «Авто»: без него
                        // аккаунт сервера не создать, и подключение просило войти в VK.
                        val linkToken = linkAccessToken.takeIf { credentialPlan.tokenFromLink }
                        val resolvedHashes = if (!vkTransport) {
                            ResolvedVkHashes("", true)
                        } else if (credentialPlan.useLinkHashes) {
                            ResolvedVkHashes(intentHashes, false)
                        } else {
                            resolveAutoHashes(
                                store,
                                intentHashes,
                                workersPerHash,
                                credentialPlan.hashModeForResolution(),
                                linkToken,
                                tokenFromLink = credentialPlan.tokenFromLink,
                            )
                        }
                        if (resolvedHashes == null) {
                            TunnelManager.starting.value = false
                            TunnelManager.updateLog(
                                "vk_auto_calls_error",
                                "Авто-режим: не удалось создать звонки VK (нет access token или ошибка VK)",
                                99,
                                true,
                            )
                            launch(Dispatchers.Main) { if (isCurrentStart(requestGeneration)) stopTunnel(finishVkCalls = true) }
                            return@launch
                        }

                        // Каждый звонок VK держит ограниченное число воркеров: сверх этого они не поднимутся.
                        val hashValues = resolvedHashes.value.split(',').map(String::trim).filter(String::isNotEmpty)
                        val jsSizedWorkers = resolvedHashes.mode == MrttConstants.VkAutoHash.MODE_AUTO_JS &&
                            hashValues.isNotEmpty()
                        val startWorkers = when {
                            // В «Авто ВК» число воркеров задаёт пользователь: звонок один, креды приходят из аккаунта.
                            jsSizedWorkers -> workersPerHash
                            vkTransport && hashValues.isNotEmpty() ->
                                WorkerCountPolicy.normalizeForHashValues(workersPerHash, hashValues)
                            else -> workersPerHash
                        }
                        if (startWorkers < workersPerHash) {
                            TunnelManager.updateLog(
                                "workers_capped",
                                "[ПОДКЛЮЧЕНИЕ] Воркеров $startWorkers вместо $workersPerHash: столько держат звонки VK (${hashValues.size})",
                                90,
                                false,
                            )
                        }

                        val domainWhite = store.domainIsWhitelist.first()
                        val domainList = if (domainWhite) store.directDomainsWhite.first() else store.directDomainsBlack.first()
                        val ipWhite = store.ipIsWhitelist.first()
                        val ipList = if (ipWhite) store.directIpsWhite.first() else store.directIpsBlack.first()
                        // Российские сервисы из geosite-category-ru тоже включают маршрутизацию.
                        val geositeRu = store.geositeRuEnabled.first()
                        val hasDomains = if (domainWhite) {
                            domainList.isNotBlank()
                        } else {
                            domainList.isNotBlank() || store.templateDomainsEnabled.first() ||
                                store.excludeRuZonesEnabled.first() || geositeRu
                        }
                        val effectiveDomainEnabled = store.domainRoutingEnabled.first() && hasDomains
                        val hasIps = ipList.isNotBlank()
                        val effectiveIpEnabled = hasIps   // the list is the switch (TunVpnService)

                        val params = TunnelParams(
                            peer = intent.getStringExtra("peer") ?: "",
                            vkHashes = resolvedHashes.value,
                            secondaryVkHash = intent.getStringExtra("secondary_vk_hash") ?: "",
                            workersPerHash = startWorkers,
                            jitsiWorkers = store.jitsiWorkers.first(),
                            jitsiSeats = intent.getIntExtra("jitsi_seats", 0),
                            port = intent.getIntExtra("port", 0),
                            sni = intent.getStringExtra("sni") ?: "",
                            connectionPassword = intent.getStringExtra("connection_password") ?: "",
                            protocol = intent.getStringExtra("protocol") ?: "udp",
                            vkAuthMode = vkAuthMode,
                            captchaMode = sanitizeCaptchaMode(intent.getStringExtra("captcha_mode")),
                            captchaSolveMethod = intent.getStringExtra("captcha_solve_method") ?: "auto",
                            fingerprint = intent.getStringExtra("fingerprint") ?: "firefox",
                            clientIds = intent.getStringExtra("client_ids") ?: MrttConstants.Tunnel.DEFAULT_CLIENT_IDS,
                            obfsMode = intent.getStringExtra("obfs_mode")
                                ?.takeIf { it == "unified" }
                                ?: MrttConstants.Tunnel.DEFAULT_OBFS_MODE,
                            turnTransport = intent.getStringExtra("turn_transport")
                                ?.takeIf { it == MrttConstants.Tunnel.TURN_TRANSPORT_TCP_TLS }
                                ?: MrttConstants.Tunnel.DEFAULT_TURN_TRANSPORT,
                            srtpMode = sanitizeSrtpMode(intent.getStringExtra("srtp_mode")),
                            customTurnIps = intent.getStringExtra("custom_turn_ips") ?: "",
                            mtu = intent.getIntExtra("mtu", MrttConstants.Vpn.DEFAULT_MTU),
                            hideFingerprint = store.hideTunnelFingerprint.first(),
                            generationId = genId,
                            sessionSalt = salt,
                            allowHashRedistribution = resolvedHashes.allowWorkerRedistribution,
                            vkHashMode = resolvedHashes.mode,
                            vkAccessToken = resolvedHashes.accessToken,
                            maxGroupId = maxGroupId,
                            jitsiRoom = jitsiRoom,
                            maxAccessToken = maxAccessToken,
                            maxDeviceId = maxDeviceId,
                            domainRoutingEnabled = effectiveDomainEnabled,
                            domainIsWhitelist = domainWhite,
                            excludeRuZones = if (domainWhite) false else store.excludeRuZonesEnabled.first(),
                            templateDomains = if (domainWhite) false else store.templateDomainsEnabled.first(),
                            directDomains = domainList,
                            ipRoutingEnabled = effectiveIpEnabled,
                            ipIsWhitelist = ipWhite,
                            directIps = ipList,
                            adblockEnabled = store.adblockEnabled.first(),
                            adblockCategories = store.adblockCategories.first(),
                            adblockDomains = store.adblockDomains.first(),
                            geositeRuEnabled = geositeRu,
                            portHideRoot = store.portHideRoot.first(),
                            portHidePackages = store.portHidePackages.first(),
                        )
                        launch(Dispatchers.Main) {
                            if (isCurrentStart(requestGeneration)) startTunnel(params)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Log.e("TunnelService", "Unable to prepare tunnel start", e)
                        TunnelManager.updateLog(
                            "service_start_error",
                            "Ошибка подготовки VPN-сервиса: ${e.message ?: e.javaClass.simpleName}",
                            99,
                            true,
                        )
                        TunnelManager.starting.value = false
                        launch(Dispatchers.Main) { if (isCurrentStart(requestGeneration)) stopTunnel(finishVkCalls = true) }
                    }
                }
            }
            "STOP", "DISCONNECT" -> {
                stopTunnel(finishVkCalls = true)
            }
            MrttConstants.General.ACTION_RESTART_WHEN_VK_REACHABLE -> verifyVkAndRestart()
            MrttConstants.General.ACTION_VERIFY_VK_REACHABILITY -> verifyVkAndSuspend()
            MrttConstants.General.ACTION_RECOVER_VK_CALL -> {
                recoverUnavailableVkCall(
                    intent.getStringExtra(MrttConstants.General.EXTRA_UNAVAILABLE_VK_HASH).orEmpty(),
                )
            }
            "DEPLOY_START" -> {
                try {
                    isStopping = false
                    resourcesReleased = false
                    val notification = createNotification("Установка на сервер...", "DEPLOY_CANCEL", "Отменить")
                    startPersistentForeground(notification)
                    prepareForDeploy()
                    acquireWakeLock()
                } catch (e: Exception) {
                    DeployManager.writeError(
                        "Deploy foreground service error (${e.javaClass.simpleName}): ${e.message}\n" +
                            e.stackTraceToString().take(1200)
                    )
                    TunnelManager.addDeployErrorLog(
                        "Не удалось запустить сервис установки: ${e.message?.take(120) ?: e.javaClass.simpleName}"
                    )
                    DeployManager.stopAll("Не удалось запустить сервис установки: ${e.message?.take(120)}")
                    runCatching { releaseTunnelResources() }
                    runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
                    foregroundStarted = false
                    stopSelf()
                    return START_NOT_STICKY
                }
            }
            "DEPLOY_CANCEL" -> {
                com.mrtt.client.DeployManager.writeError("✗ Установка отменена пользователем")
                com.mrtt.client.DeployManager.cancelAll()
                if (TunnelManager.running.value) {
                    lastNotificationText = null
                    lastNotificationPostElapsedMs = 0L
                    updateNotification(buildTunnelNotificationText())
                } else {
                    stopTunnel()
                }
            }
            "DEPLOY_STOP" -> {
                // Другие серверы ещё ставятся: сервис и уведомление нужны им.
                if (DeployManager.isDeploying.value) return START_STICKY
                if (!TunnelManager.running.value) {
                    stopTunnel()
                } else {
                    updateNotification("Туннель активен")
                }
            }
            "RESTORE_NOTIFICATION" -> {
                if (foregroundStarted && !isStopping) {
                    lastNotificationText = null
                    lastNotificationPostElapsedMs = 0L
                    updateNotification(currentNotificationText())
                }
            }
        }
        return START_STICKY
    }

    private fun restoreTunnel(): Boolean {
        if (isStopping || !serviceJob.isActive) return false
        startJob?.cancel()
        val requestGeneration = ++startGeneration
        isStopping = false
        resourcesReleased = false
        TunnelManager.starting.value = true
        val notification = createNotification("Восстановление соединения...")
        if (!tryStartPersistentForeground(notification, "восстановление VPN")) {
            TunnelManager.starting.value = false
            stopSelf()
            return false
        }

        val appContext = applicationContext
        startJob = serviceScope.launch {
            try {
                val store = SettingsStore(appContext)

                val wasRunning = store.tunnelWasRunning.first()
                if (!wasRunning) {
                    Log.d("TunnelService", "restoreTunnel: tunnelWasRunning=false, автостарт отменён — чужой VPN не нужно убивать")
                    launch(Dispatchers.Main) { stopTunnel() }
                    return@launch
                }
                autoPauseRequested = true
                autoPauseOnWifiEnabled = store.autoPauseOnWifi.first()
                TunnelManager.isLoggingEnabled = store.loggingEnabled.first()
                if (reconcileWifiAutoPause()) return@launch

                val source = resolveConnectionSource(store)
                if (source == null) {
                    TunnelManager.updateLog(
                        "connection_source_error",
                        "[ПОДКЛЮЧЕНИЕ] Не удалось разобрать сохранённую ссылку или найти адрес сервера. Откройте настройки подключения.",
                        99,
                        true,
                    )
                    launch(Dispatchers.Main) {
                        if (isCurrentStart(requestGeneration)) stopTunnel(finishVkCalls = true)
                    }
                    return@launch
                }
                if (
                    !store.mrttLinkMode.first() &&
                    store.connectionPasswordState.first().state == StoredSecretState.Unreadable
                ) {
                    TunnelManager.updateLog(
                        "connection_secret_unreadable",
                        "[ПОДКЛЮЧЕНИЕ] Не удалось прочитать сохранённый пароль подключения. Откройте настройки и введите его заново.",
                        99,
                        true,
                    )
                    launch(Dispatchers.Main) {
                        if (isCurrentStart(requestGeneration)) stopTunnel(finishVkCalls = true)
                    }
                    return@launch
                }
                val genId = store.reserveConnectionGeneration()
                val salt = newTunnelSessionId()
                val requestedVkAuthMode = sanitizeVkAuthMode(store.vkAuthMode.first())
                val workersPerHash = WorkerCountPolicy.normalize(store.workersPerHash.first())
                TunnelManager.isLoggingEnabled = store.loggingEnabled.first()
                val credentialPlan = planVkCredentials(
                    requestedAuthMode = requestedVkAuthMode,
                    hashesFromLink = source.hashesFromLink,
                    linkTokenPresent = source.tokenFromLink,
                    ownVkSessionBound = store.hasAnyVkBinding(),
                    preferLinkVk = store.vkPreferLinkHashes.first(),
                )
                val vkAuthMode = credentialPlan.authMode
                val vkTransport = source.maxGroupId.isBlank() && source.jitsiRoom.isBlank()
                if (vkTransport && !awaitVkNetwork()) {
                    TunnelManager.starting.value = false
                    return@launch
                }
                if (!isCurrentStart(requestGeneration)) return@launch
                val restoredHashes = when {
                    !vkTransport -> ResolvedVkHashes("", true)
                    credentialPlan.useLinkHashes -> ResolvedVkHashes(source.hashes, false)
                    credentialPlan.tokenFromLink -> resolveAutoHashes(
                        store,
                        source.hashes,
                        workersPerHash,
                        credentialPlan.hashModeForResolution(),
                        source.vkAccessToken,
                        tokenFromLink = true,
                    )
                    else -> resolveAutoHashes(
                        store,
                        source.hashes,
                        workersPerHash,
                        credentialPlan.hashModeForResolution(),
                        accessTokenOverride = null,
                        tokenFromLink = false,
                    )
                }
                val domainWhite = store.domainIsWhitelist.first()
                val domainList = if (domainWhite) store.directDomainsWhite.first() else store.directDomainsBlack.first()
                val ipWhite = store.ipIsWhitelist.first()
                val ipList = if (ipWhite) store.directIpsWhite.first() else store.directIpsBlack.first()
                val ipRouting = ipList.isNotBlank()   // the list is the switch (TunVpnService)

                val params = TunnelParams(
                    peer = source.peer,
                    vkHashes = restoredHashes?.value ?: "",
                    secondaryVkHash = store.secondaryVkHash.first(),
                    jitsiWorkers = store.jitsiWorkers.first(),
                    jitsiSeats = source.jitsiSeats,
                    workersPerHash = workersPerHash,
                    port = 0,
                    sni = store.sni.first(),
                    connectionPassword = source.password,
                    obfsMode = store.obfsMode.first(),
                    turnTransport = store.turnTransport.first(),
                    srtpMode = sanitizeSrtpMode(store.srtpMode.first()),
                    customTurnIps = store.customTurnIps.first(),
                    mtu = store.tunnelMtu.first(),
                    hideFingerprint = store.hideTunnelFingerprint.first(),
                    vkAuthMode = vkAuthMode,
                    captchaMode = sanitizeCaptchaMode(store.captchaMode.first()),
                    captchaSolveMethod = store.captchaSolveMethod.first(),
                    fingerprint = store.selectedFingerprint.first(),
                    clientIds = store.activeClientIds.first(),
                    generationId = genId,
                    sessionSalt = salt,
                    allowHashRedistribution = restoredHashes?.allowWorkerRedistribution == true,
                    vkHashMode = restoredHashes?.mode ?: MrttConstants.VkAutoHash.MODE_MANUAL,
                    vkAccessToken = restoredHashes?.accessToken.orEmpty(),
                    maxGroupId = source.maxGroupId,
                    jitsiRoom = source.jitsiRoom,
                    maxAccessToken = store.maxAccessToken.first(),
                    maxDeviceId = store.maxDeviceId.first(),
                    // Российские сервисы: список geosite-category-ru тоже требует
                    // включённой маршрутизации, иначе клиент его не прочитает.
                    domainRoutingEnabled = store.domainRoutingEnabled.first() ||
                        (!domainWhite && store.templateDomainsEnabled.first()) ||
                        domainList.isNotBlank() ||
                        (!domainWhite && store.excludeRuZonesEnabled.first()) ||
                        (!domainWhite && store.geositeRuEnabled.first()),
                    domainIsWhitelist = domainWhite,
                    excludeRuZones = if (domainWhite) false else store.excludeRuZonesEnabled.first(),
                    templateDomains = if (domainWhite) false else store.templateDomainsEnabled.first(),
                    directDomains = domainList,
                    ipRoutingEnabled = ipRouting,
                    ipIsWhitelist = ipWhite,
                    directIps = ipList,
                    adblockEnabled = store.adblockEnabled.first(),
                    adblockCategories = store.adblockCategories.first(),
                    adblockDomains = store.adblockDomains.first(),
                    geositeRuEnabled = store.geositeRuEnabled.first(),
                    portHideRoot = store.portHideRoot.first(),
                    portHidePackages = store.portHidePackages.first(),
                )
                if (
                    params.peer.isNotEmpty() &&
                    (
                        (params.maxGroupId.isNotBlank() && params.maxAccessToken.isNotBlank()) ||
                        params.jitsiRoom.isNotBlank() ||
                        params.vkHashes.isNotEmpty() ||
                            params.vkHashMode == MrttConstants.VkAutoHash.MODE_AUTO_JS
                    )
                ) {
                    launch(Dispatchers.Main) {
                        if (isCurrentStart(requestGeneration)) startTunnel(params)
                    }
                } else {
                    TunnelManager.updateLog(
                        "connection_credentials_error",
                        "[ПОДКЛЮЧЕНИЕ] В ссылке и настройках нет действующих VK-хэшей или VK-токена.",
                        99,
                        true,
                    )
                    launch(Dispatchers.Main) {
                        if (isCurrentStart(requestGeneration)) stopTunnel(finishVkCalls = true)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("TunnelService", "Unable to restore tunnel", e)
                TunnelManager.updateLog(
                    "service_restore_error",
                    "Ошибка восстановления VPN: ${e.message ?: e.javaClass.simpleName}",
                    99,
                    true,
                )
                launch(Dispatchers.Main) {
                    if (isCurrentStart(requestGeneration)) stopTunnel(finishVkCalls = true)
                }
            }
        }
        return true
    }

    private suspend fun resolveAutoHashes(
        store: SettingsStore,
        fallbackHashes: String,
        workersPerHash: Int,
        forcedMode: String? = null,
        accessTokenOverride: String? = null,
        tokenFromLink: Boolean = false,
    ): ResolvedVkHashes? {
        return when (val mode = forcedMode ?: store.vkHashMode.first()) {
            MrttConstants.VkAutoHash.MODE_AUTO_API -> {
                val token = accessTokenOverride ?: sessionToken(store)
                val result = VkAutoCallsManager.startAutoCalls(
                    applicationContext,
                    token,
                    workersPerHash,
                    clearStoredTokenOnInvalid = !tokenFromLink,
                )
                    ?: return null
                ResolvedVkHashes(
                    result.hashes,
                    result.needsWorkerRedistribution,
                    mode,
                )
            }

            MrttConstants.VkAutoHash.MODE_AUTO_JS -> {
                val token = accessTokenOverride ?: sessionToken(store)
                if (token.isBlank()) return null
                // Rust создаёт один звонок через браузерную цепочку. Если именно это не выходит
                // (VK меняет методы, аккаунту нужен телефон, звонок не создаётся), хеши не теряем:
                // создаём их через calls.start, а креды при этом всё равно берутся из аккаунта.
                val startedCalls = VkAutoCallsManager.startAutoCalls(
                    applicationContext,
                    token,
                    workersPerHash,
                    clearStoredTokenOnInvalid = !tokenFromLink,
                )
                val fallbackHashes = startedCalls?.hashes.orEmpty()
                if (startedCalls != null) {
                    TunnelManager.updateLog(
                        "vk_auto_js_fallback",
                        "[VK JS] Звонок браузерной цепочкой не создан · хеши взяты через calls.start (${startedCalls.createdCalls})",
                        45,
                        false,
                    )
                }
                ResolvedVkHashes(
                    fallbackHashes,
                    true,
                    mode,
                    token,
                )
            }

            else -> ResolvedVkHashes(fallbackHashes, false)
        }
    }

    /**
     * Токен из сохранённой сессии VK.
     *
     * Сессия — это куки. Токен из них получается заново перед каждым подключением,
     * поэтому «истёк токен» больше не значит «войдите заново»: заново нужен только
     * вход, когда VK перестал принимать сами куки (сессия отозвана).
     */
    private suspend fun sessionToken(store: SettingsStore): String {
        // Сначала — вход через приложение ВК: там привязка уже токен, и он
        // обновляется по refresh_token без повторного входа человека.
        refreshVkIdTokenIfSaved(store)?.let { return it }
        val session = store.vkSession.first()
        if (session.isBlank()) return ""
        return try {
            VkTokenScraper.fetchAccessToken(session)
        } catch (error: kotlinx.coroutines.CancellationException) {
            throw error
        } catch (error: Exception) {
            val reason = error.message ?: error.javaClass.simpleName
            val cookiesRejected = reason.contains("API 5") ||
                reason.contains("API 4") ||
                reason.contains("API 28") ||
                reason.contains("web_token")
            TunnelManager.updateLog(
                "vk_session_error",
                if (cookiesRejected) {
                    "[ERR] VK не принял сохранённую сессию ($reason) · войдите в аккаунт заново"
                } else {
                    "[ERR] Не удалось получить VK токен из сессии · $reason"
                },
                95,
                true,
            )
            ""
        }
    }

    /**
     * Свежий токен входа через приложение ВК.
     *
     * Токен VK ID живёт около часа, поэтому его нельзя просто хранить: перед
     * каждым подключением обновляем по `refresh_token` и сохраняем новый (ВК
     * отдаёт новую пару, старый refresh может стать недействительным).
     */
    private suspend fun refreshVkIdTokenIfSaved(store: SettingsStore): String? {
        val saved = store.vkIdToken.first()
        if (saved.isBlank()) return null
        val refresh = store.vkIdRefreshToken.first()
        if (refresh.isBlank()) return saved
        return try {
            val tokens = VkTokenScraper.refreshVkIdToken(refresh)
            store.saveVkIdTokens(tokens.accessToken, tokens.refreshToken.ifBlank { refresh }, tokens.userId)
            // Тихо: строка нужна в журнале, но не как ошибка и не как событие сети.
            TunnelManager.updateLog(
                "vk_id_token_refreshed",
                "[VK] Вход через приложение обновлён ✓",
                34,
                false,
            )
            tokens.accessToken
        } catch (error: kotlinx.coroutines.CancellationException) {
            throw error
        } catch (error: Exception) {
            // Не смогли обновить: пробуем то, что сохранено. Если ВК его уже не
            // принимает, клиент вернёт код 4 и приложение попросит войти заново.
            TunnelManager.updateLog(
                "vk_id_token_refresh_failed",
                "[VK] Не удалось обновить вход через приложение: ${error.message ?: "ошибка VK"}",
                90,
                false,
            )
            saved
        }
    }

    private fun recoverUnavailableVkCall(hash: String) {
        if (hash.isBlank()) {
            TunnelManager.completeVkCallRecovery()
            return
        }
        serviceScope.launch {
            var restartScheduled = false
            try {
                val previous = TunnelManager.getCurrentParams() ?: return@launch
                if (previous.maxGroupId.isNotBlank() || previous.jitsiRoom.isNotBlank()) return@launch
                val store = SettingsStore(applicationContext)
                val vkHashMode = store.vkHashMode.first()
                val source = resolveConnectionSource(store) ?: return@launch
                if (vkHashMode == MrttConstants.VkAutoHash.MODE_MANUAL && !source.tokenFromLink) {
                    return@launch
                }
                // Восстановление идёт тем же режимом, что был у подключения: собственный
                // вход в VK не должен превращаться в аккаунт сервера только из-за ссылки.
                val accountAutoJs = previous.vkAuthMode == MrttConstants.VkAuth.MODE_AUTO_JS
                val workers = WorkerCountPolicy.normalize(
                    store.workersPerHash.first(),
                    maximum = MrttConstants.Tunnel.MAX_WORKERS,
                )
                // Свой вход в VK важнее токена из ссылки, если подключение шло через «Авто ВК».
                val useLinkToken = source.tokenFromLink && !accountAutoJs
                val resolved = when {
                    accountAutoJs -> resolveAutoHashes(
                        store,
                        fallbackHashes = "",
                        workersPerHash = workers,
                        forcedMode = MrttConstants.VkAutoHash.MODE_AUTO_JS,
                        accessTokenOverride = null,
                        tokenFromLink = false,
                    )
                    vkHashMode == MrttConstants.VkAutoHash.MODE_AUTO_API || useLinkToken -> resolveAutoHashes(
                        store,
                        fallbackHashes = source.hashes,
                        workersPerHash = workers,
                        forcedMode = if (useLinkToken) MrttConstants.VkAutoHash.MODE_AUTO_API else null,
                        accessTokenOverride = source.vkAccessToken.takeIf { useLinkToken },
                        tokenFromLink = useLinkToken,
                    )
                    else -> ResolvedVkHashes(source.hashes, false)
                } ?: return@launch
                if (resolved.value.isBlank() && resolved.mode != MrttConstants.VkAutoHash.MODE_AUTO_JS) {
                    launch(Dispatchers.Main) { TunnelManager.stop() }
                    return@launch
                }
                val nextGeneration = store.reserveConnectionGeneration(
                    proposed = if (previous.generationId == Long.MAX_VALUE) {
                        Long.MAX_VALUE
                    } else {
                        previous.generationId + 1
                    },
                )
                val next = previous.copy(
                    peer = source.peer,
                    vkHashes = resolved.value,
                    workersPerHash = workers,
                    connectionPassword = source.password,
                    vkAuthMode = if (accountAutoJs) MrttConstants.VkAuth.MODE_AUTO_JS else previous.vkAuthMode,
                    generationId = nextGeneration,
                    sessionSalt = newTunnelSessionId(),
                    allowHashRedistribution = resolved.allowWorkerRedistribution,
                    vkHashMode = resolved.mode,
                    vkAccessToken = resolved.accessToken,
                )
                launch(Dispatchers.Main) {
                    TunnelManager.start(applicationContext, next, isSwitching = true)
                }
                restartScheduled = true
            } finally {
                if (!restartScheduled) TunnelManager.completeVkCallRecovery()
            }
        }
    }

    private fun tryStartPersistentForeground(notification: Notification, operation: String): Boolean {
        return try {
            startPersistentForeground(notification)
            true
        } catch (e: Exception) {
            Log.e("TunnelService", "Foreground service rejected during $operation", e)
            TunnelManager.updateLog(
                "foreground_start_error",
                "Android заблокировал foreground-сервис ($operation): ${e.message ?: e.javaClass.simpleName}",
                99,
                true,
            )
            false
        }
    }

    private fun isCurrentStart(generation: Long): Boolean =
        generation == startGeneration && !isStopping && serviceJob.isActive

    private fun startTunnel(params: TunnelParams) {
        if (isStopping || !serviceJob.isActive) return
        autoPauseRequested = true
        if (autoPauseOnWifiEnabled && wifiConnectedForAutoPause()) {
            serviceScope.launch { reconcileWifiAutoPause() }
            return
        }
        updateNotification("Подключение...")
        acquireWakeLock()
        acquireWifiLock()

        CaptchaWebViewManager.onTunnelStart(applicationContext)

        serviceScope.launch {
            runCatching { SettingsStore(applicationContext).saveTunnelWasRunning(true) }
        }

        TunnelManager.start(this, params)
        if (!physicalNetworks.hasUsableNetwork()) {
            TunnelManager.suspendForNoNetwork(physicalNetworkPauseReason(isAirplaneModeOn()))
        }
        TunnelManager.scope.launch(Dispatchers.Main) {
            VkAutoCallsManager.replayPendingLogs()
        }
        startStatsUpdater()
    }

    private fun registerPhysicalNetworkCallback() {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                networkLossJob?.cancel()
                networkLossJob = null
                requestWifiAutoPauseReconciliation()
                rememberPhysicalCandidate(network)
                if (autoPausedForWifi) return
                startVkNetworkProbe(network)
            }

            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                updatePhysicalWifiNetwork(network, capabilities)
                requestWifiAutoPauseReconciliation()
                if (hasPhysicalInternetCapability(capabilities)) {
                    rememberPhysicalCandidate(network)
                    if (autoPausedForWifi) return
                    startVkNetworkProbe(network)
                } else {
                    forgetPhysicalNetwork(network)
                }
            }

            override fun onLost(network: Network) {
                forgetPhysicalWifiNetwork(network)
                requestWifiAutoPauseReconciliation()
                forgetPhysicalNetwork(network)
            }
        }
        networkCallback = callback
        runCatching {
            connectivityManager.registerNetworkCallback(
                NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build(),
                callback,
            )
        }.onFailure {
            Log.w("TunnelService", "Unable to register physical network callback", it)
            networkCallback = null
        }
    }

    private fun rememberPhysicalCandidate(network: Network) {
        synchronized(vkProbeLock) {
            physicalCandidates.add(network)
        }
    }

    private fun isPhysicalCandidate(network: Network): Boolean = synchronized(vkProbeLock) {
        network in physicalCandidates
    }

    private fun startVkNetworkProbe(network: Network) {
        if (autoPausedForWifi) return
        if (physicalNetworks.isUsable(network)) return
        synchronized(vkProbeLock) {
            if (network !in physicalCandidates || vkProbeJobs[network]?.isActive == true) return
            val job = serviceScope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) {
                var failures = 0
                try {
                    while (isActive && !physicalNetworks.isUsable(network)) {
                        if (probeVkThrough(network)) {
                            if (!isActive || !isPhysicalCandidate(network)) return@launch
                            updatePhysicalNetwork(network, true)
                            return@launch
                        }
                        failures++
                        delay(vkProbeRetryDelayMs(failures))
                    }
                } finally {
                    synchronized(vkProbeLock) {
                        if (vkProbeJobs[network] === coroutineContext[Job]) {
                            vkProbeJobs.remove(network)
                        }
                    }
                }
            }
            vkProbeJobs[network] = job
            job.start()
        }
    }

    private fun forgetPhysicalNetwork(network: Network) {
        synchronized(vkProbeLock) {
            physicalCandidates.remove(network)
            vkProbeJobs.remove(network)?.cancel()
        }
        updatePhysicalNetwork(network, false)
    }

    private fun probeVkThrough(network: Network): Boolean =
        TunnelManager.getCurrentParams().let { params ->
            when {
                params?.jitsiRoom?.isNotBlank() == true -> listOf("https://${params.jitsiRoom.substringBefore('/')}/")
                params?.maxGroupId?.isNotBlank() == true -> MAX_PROBE_URLS
                else -> VK_PROBE_URLS
            }
        }
            .any { address ->
        val url = URL(address)
        probeVkRequest { network.openConnection(url) as HttpURLConnection }
            ?: probeVkUnboundFallback(network, url)
    }

    private fun probeVkUnboundFallback(network: Network, url: URL): Boolean {
        val active = runCatching { connectivityManager.activeNetwork }.getOrNull()
        if (active != null && active != network) return false
        return probeVkRequest { url.openConnection() as HttpURLConnection } ?: false
    }

    private fun probeVkRequest(open: () -> HttpURLConnection): Boolean? {
        val connection = runCatching(open).getOrNull() ?: return null
        return try {
            connection.instanceFollowRedirects = false
            connection.connectTimeout = VK_PROBE_CONNECT_TIMEOUT_MS
            connection.readTimeout = VK_PROBE_READ_TIMEOUT_MS
            connection.useCaches = false
            connection.requestMethod = "GET"
            connection.setRequestProperty("Connection", "close")
            connection.setRequestProperty("Range", "bytes=0-0")
            connection.setRequestProperty("Accept-Encoding", "identity")
            connection.setRequestProperty("User-Agent", "Mozilla/5.0")
            isVkProbeHttpResponse(connection.responseCode)
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private suspend fun awaitVkNetwork(): Boolean {
        val deadline = SystemClock.elapsedRealtime() + 60_000L
        while (
            serviceScope.coroutineContext[Job]?.isActive != false &&
            SystemClock.elapsedRealtime() < deadline
        ) {
            if (physicalNetworks.hasUsableNetwork()) return true
            currentPhysicalCandidates().forEach { network ->
                rememberPhysicalCandidate(network)
                startVkNetworkProbe(network)
            }
            delay(250)
        }
        if (serviceScope.coroutineContext[Job]?.isActive != false) {
            TunnelManager.updateLog(
                "vk_network_timeout",
                "[СЕТЬ] Не удалось дождаться доступной сети VK за 60 секунд.",
                99,
                true,
            )
        }
        return false
    }

    private fun currentPhysicalCandidates(): List<Network> {
        val candidates = synchronized(vkProbeLock) { physicalCandidates.toList() }
        if (candidates.isNotEmpty()) return candidates
        val active = runCatching { connectivityManager.activeNetwork }.getOrNull() ?: return emptyList()
        val usable = runCatching {
            connectivityManager.getNetworkCapabilities(active)
                ?.let(::hasPhysicalInternetCapability) == true
        }.getOrDefault(false)
        return if (usable) listOf(active) else emptyList()
    }

    private fun verifyVkAndRestart() {
        if (vkRecoveryJob?.isActive == true) return
        vkRecoveryJob = serviceScope.launch(Dispatchers.IO) {
            try {
                if (!TunnelManager.running.value || TunnelManager.activeWorkers.value != 0) {
                    return@launch
                }
                val candidates = currentPhysicalCandidates()
                val ready = candidates.firstOrNull(::probeVkThrough)
                if (ready != null) {
                    rememberPhysicalCandidate(ready)
                    updatePhysicalNetwork(ready, true)
                    if (TunnelManager.activeWorkers.value == 0) {
                        TunnelManager.restartAfterVkRecovery(applicationContext)
                    }
                    return@launch
                }
                candidates.forEach { network ->
                    rememberPhysicalCandidate(network)
                    startVkNetworkProbe(network)
                }
            }
            finally {
                if (vkRecoveryJob === coroutineContext[Job]) vkRecoveryJob = null
            }
        }
    }

    private fun verifyVkAndSuspend() {
        if (vkRecoveryJob?.isActive == true) return
        vkRecoveryJob = serviceScope.launch(Dispatchers.IO) {
            try {
                val candidates = currentPhysicalCandidates()
                val ready = candidates.firstOrNull(::probeVkThrough)
                if (ready != null) {
                    rememberPhysicalCandidate(ready)
                    updatePhysicalNetwork(ready, true)
                    return@launch
                }
                candidates.forEach { network ->
                    rememberPhysicalCandidate(network)
                    startVkNetworkProbe(network)
                }
            } finally {
                if (vkRecoveryJob === coroutineContext[Job]) vkRecoveryJob = null
            }
        }
    }

    private fun updatePhysicalNetwork(network: Network, usable: Boolean) {
        val transition = physicalNetworks.update(network, usable)
        if (autoPausedForWifi) return
        when (transition) {
            PhysicalNetworkTransition.AVAILABLE -> {
                networkLossJob?.cancel()
                networkLossJob = null
                TunnelManager.onPhysicalNetworkAvailable(applicationContext)
            }
            PhysicalNetworkTransition.UNAVAILABLE -> {
                networkSwapJob?.cancel()
                schedulePhysicalNetworkLossCheck()
            }
            PhysicalNetworkTransition.CHANGED -> Unit
            PhysicalNetworkTransition.NONE -> Unit
        }
    }

    private fun schedulePhysicalNetworkLossCheck() {
        if (networkLossJob?.isActive == true) return
        networkLossJob = serviceScope.launch {
            delay(NETWORK_LOSS_GRACE_MS)
            if (physicalNetworks.hasUsableNetwork() || autoPausedForWifi) return@launch

            currentPhysicalCandidates().forEach { network ->
                rememberPhysicalCandidate(network)
                startVkNetworkProbe(network)
            }
            if (!physicalNetworks.hasUsableNetwork()) {
                TunnelManager.suspendForNoNetwork(physicalNetworkPauseReason(isAirplaneModeOn()))
            }
        }.also { job ->
            job.invokeOnCompletion {
                if (networkLossJob === job) networkLossJob = null
            }
        }
    }

    private fun registerAirplaneModeReceiver() {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action != Intent.ACTION_AIRPLANE_MODE_CHANGED) return
                if (isAirplaneModeOn() && !physicalNetworks.hasUsableNetwork()) {
                    TunnelManager.suspendForNoNetwork(physicalNetworkPauseReason(true))
                }
            }
        }
        val registered = runCatching {
            ContextCompat.registerReceiver(
                this,
                receiver,
                IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED),
                ContextCompat.RECEIVER_EXPORTED,
            )
        }.isSuccess
        if (registered) airplaneModeReceiver = receiver
    }

    private fun hasPhysicalInternetCapability(capabilities: NetworkCapabilities): Boolean =
        isEligiblePhysicalNetwork(
            hasInternet = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
            notVpn = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN),
            wifi = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI),
            cellular = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR),
        )

    private fun isAirplaneModeOn(): Boolean =
        runCatching {
            Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) != 0
        }.getOrDefault(false)

    private fun stopTunnel(finishVkCalls: Boolean = false) {
        startJob?.cancel()
        startJob = null
        startGeneration++
        if (isStopping) return
        isStopping = true
        TunnelManager.stopping.value = true
        stopWifiAutoPauseWatch()
        autoPauseRequested = false
        TunnelManager.starting.value = false
        updateJob?.cancel()
        serviceScope.launch {
            // An in-flight pause can be suspended in DataStore/manager cleanup.
            // Finish manual shutdown after it; the final persisted intent is off.
            autoPauseMutex.withLock {
                autoPausedForWifi = false
                TunnelManager.leaveWifiAutoPause()
                runCatching { SettingsStore(applicationContext).saveTunnelWasRunning(false) }
                releaseTunnelResources(finishVkCalls)
                stopForeground(STOP_FOREGROUND_REMOVE)
                foregroundStarted = false
                stopSelf()
            }
        }
    }

    private fun prepareForDeploy() {
        updateJob?.cancel()
        updateJob = null
        CaptchaWebViewManager.onTunnelStop()
        TunnelManager.stop(notifyController = false)
        releaseWifiLock()
    }

    private fun releaseTunnelResources(finishVkCalls: Boolean = false) {
        if (resourcesReleased) return
        resourcesReleased = true
        stopWifiAutoPauseWatch()
        CaptchaWebViewManager.onTunnelStop()
        if (finishVkCalls) VkAutoCallsManager.finishActiveCalls()
        TunnelManager.stop(finishVkCalls, notifyController = false)
        releaseWakeLock()
        releaseWifiLock()
    }

    private fun observeAutoPauseOnWifi() {
        autoPauseSettingsJob?.cancel()
        autoPauseSettingsJob = serviceScope.launch {
            SettingsStore(applicationContext).autoPauseOnWifi.collect { enabled ->
                autoPauseOnWifiEnabled = enabled
                reconcileWifiAutoPause()
            }
        }
    }

    /**
     * «Экономия батареи»: in force («Авто» — the phone's battery saver is on; «Свой уровень» — at or below the chosen
     * charge and not charging), the service lets go of its wake lock and TunVpnService of its own; out of force again,
     * they are taken back while the tunnel runs. The charge and the phone's saver come from their broadcasts, which
     * arrive only while the CPU is awake anyway.
     */
    private fun observeBatterySaver() {
        val powerManager = getSystemService(PowerManager::class.java)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == PowerManager.ACTION_POWER_SAVE_MODE_CHANGED) {
                    systemPowerSave = powerManager?.isPowerSaveMode == true
                } else {
                    readBattery(intent)
                }
                reconcileBatterySaver()
            }
        }
        systemPowerSave = powerManager?.isPowerSaveMode == true
        runCatching {
            ContextCompat.registerReceiver(
                this,
                receiver,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED).apply {
                    addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
                },
                ContextCompat.RECEIVER_NOT_EXPORTED,
            )
        }.onSuccess { sticky ->
            batteryReceiver = receiver
            sticky?.let(::readBattery)
        }
        batterySaverJob?.cancel()
        batterySaverJob = serviceScope.launch {
            val store = SettingsStore(applicationContext)
            combine(store.batterySaverMode, store.batterySaverPercent) { mode, percent -> mode to percent }
                .collect { (mode, percent) ->
                    batterySaverMode = mode
                    batterySaverPercent = percent
                    batterySaverLoaded = true
                    withContext(Dispatchers.Main) { reconcileBatterySaver() }
                }
        }
    }

    private fun readBattery(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        batteryLevel = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        batteryCharging = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0 ||
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun reconcileBatterySaver() {
        if (!batterySaverLoaded) return
        val save = BatterySaver.shouldSave(
            batterySaverMode, batterySaverPercent, batteryLevel, batteryCharging, systemPowerSave,
        )
        if (save == BatterySaver.active.value) return
        BatterySaver.setActive(save)
        if (save) {
            if (!DeployManager.isDeploying.value) releaseWakeLock()
            TunnelManager.updateLog(
                "battery_saver",
                if (batterySaverMode == BatterySaver.MODE_AUTO) {
                    "[BAT] Экономия батареи: включено энергосбережение телефона — при выключенном экране туннель может засыпать"
                } else {
                    "[BAT] Экономия батареи: заряд $batteryLevel % — при выключенном экране туннель может засыпать"
                },
                2,
            )
        } else {
            if (TunnelManager.running.value && !autoPausedForWifi) acquireWakeLock()
            TunnelManager.updateLog("battery_saver", "[BAT] Экономия батареи выключена — туннель снова не засыпает", 2)
        }
        TunVpnService.instance?.onBatterySaverChanged(save)
    }

    private fun observeDomainRoutingSettings() {
        domainRoutingSettingsJob?.cancel()
        domainRoutingSettingsJob = serviceScope.launch {
            val store = SettingsStore(applicationContext)
            combine(
                store.domainRoutingEnabled,
                store.excludeRuZonesEnabled,
                store.templateDomainsEnabled,
                store.directDomains,
            ) { domainEnabled, excludeRu, templateEnabled, domains ->
                DomainRoutingUpdate(
                    enabled = domainEnabled || templateEnabled || domains.isNotBlank() || excludeRu,
                    excludeRuZones = excludeRu,
                    templateDomains = templateEnabled,
                    directDomains = domains,
                )
            }.distinctUntilChanged().collect { update ->
                if (TunnelManager.running.value && !TunnelManager.serverRoutingActive.value) {
                    TunnelManager.updateDomainRouting(
                        enabled = update.enabled,
                        excludeRuZones = update.excludeRuZones,
                        templateDomains = update.templateDomains,
                        directDomains = update.directDomains,
                    )
                }
            }
        }
    }

    private fun requestWifiAutoPauseReconciliation() {
        serviceScope.launch {
            reconcileWifiAutoPause()
        }
    }

    private suspend fun reconcileWifiAutoPause(): Boolean = runWifiAutoPauseTransition(serviceScope) {
        autoPauseMutex.withLock {
            if (isStopping) return@withLock autoPausedForWifi
            when (
                wifiAutoPauseAction(
                    enabled = autoPauseOnWifiEnabled,
                    wifiConnected = wifiConnectedForAutoPause(),
                    desiredRunning = autoPauseRequested,
                    paused = autoPausedForWifi,
                )
            ) {
                WifiAutoPauseAction.PAUSE -> enterWifiAutoPause()
                WifiAutoPauseAction.RESUME -> resumeFromWifiAutoPause()
                WifiAutoPauseAction.NONE -> Unit
            }
            autoPausedForWifi
        }
    }

    private suspend fun enterWifiAutoPause() {
        if (!autoPauseRequested || !autoPauseOnWifiEnabled || !wifiConnectedForAutoPause()) return
        autoPausedForWifi = true
        updateJob?.cancel()
        updateJob = null
        networkSwapJob?.cancel()
        networkSwapJob = null
        vkRecoveryJob?.cancel()
        vkRecoveryJob = null
        startJob?.cancel()
        startJob = null
        startGeneration++
        synchronized(vkProbeLock) {
            vkProbeJobs.values.forEach(Job::cancel)
            vkProbeJobs.clear()
        }
        CaptchaWebViewManager.onTunnelStop()
        val completed = completeWifiAutoPause(
            isRequested = { autoPauseRequested && !isStopping },
            saveRunningIntent = { SettingsStore(applicationContext).saveTunnelWasRunning(true) },
            pauseDataPlane = { TunnelManager.pauseForWifi() },
        )
        if (!completed) return
        releaseWakeLock()
        releaseWifiLock()
        updateNotification("Ожидание. Автопауза при Wi-Fi")
        startWifiAutoPauseWatch()
    }

    private fun resumeFromWifiAutoPause() {
        if (!autoPausedForWifi || !autoPauseRequested || isStopping) return
        autoPausedForWifi = false
        stopWifiAutoPauseWatch()
        TunnelManager.leaveWifiAutoPause()
        acquireWakeLock()
        TunnelManager.updateLog(
            "wifi_auto_resume",
            "[NET] Автопауза Wi-Fi завершена · восстановление подключения",
            2,
            false,
            LogLevel.NET,
        )
        updateNotification("Подключение...")
        if (!restoreTunnel()) stopTunnel()
    }

    private fun startWifiAutoPauseWatch() {
        if (autoPauseWifiWatchJob?.isActive == true) return
        val job = serviceScope.launch(start = CoroutineStart.LAZY) {
            try {
                while (autoPausedForWifi && autoPauseRequested && isActive) {
                    delay(AUTO_PAUSE_WIFI_RECONCILE_MS)
                    reconcileWifiAutoPause()
                }
            } finally {
                if (autoPauseWifiWatchJob === coroutineContext[Job]) {
                    autoPauseWifiWatchJob = null
                }
            }
        }
        autoPauseWifiWatchJob = job
        job.start()
    }

    private fun stopWifiAutoPauseWatch() {
        autoPauseWifiWatchJob?.cancel()
        autoPauseWifiWatchJob = null
    }

    private fun updatePhysicalWifiNetwork(network: Network, capabilities: NetworkCapabilities) {
        val physicalWifi = hasPhysicalWifiCapability(capabilities)
        synchronized(wifiNetworkLock) {
            if (physicalWifi) {
                physicalWifiNetworks.add(network)
            } else {
                physicalWifiNetworks.remove(network)
            }
        }
    }

    private fun forgetPhysicalWifiNetwork(network: Network) {
        synchronized(wifiNetworkLock) {
            physicalWifiNetworks.remove(network)
        }
    }

    private fun wifiConnectedForAutoPause(): Boolean {
        return effectiveWifiAutoPauseConnection(
            callbackWifiConnected = hasPhysicalWifiNetwork(),
            defaultPhysicalWifiConnected = defaultPhysicalWifiNetwork(),
        )
    }

    private fun defaultPhysicalWifiNetwork(): Boolean? {
        // During a handover/closing TUN, Android can briefly have no default.
        // That is unknown, not proof that a still-present Wi-Fi disappeared.
        val active = runCatching { connectivityManager.activeNetwork }.getOrNull() ?: return null
        val capabilities = runCatching { connectivityManager.getNetworkCapabilities(active) }.getOrNull()
            ?: return null
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return null
        return hasPhysicalWifiCapability(capabilities)
    }

    private fun hasPhysicalWifiNetwork(): Boolean {
        synchronized(wifiNetworkLock) {
            return physicalWifiNetworks.isNotEmpty()
        }
    }

    private fun hasPhysicalWifiCapability(capabilities: NetworkCapabilities): Boolean =
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) &&
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)

    private fun sanitizeCaptchaMode(mode: String?): String {
        return when (mode?.lowercase()) {
            "auto" -> "auto"
            "rjs" -> "rjs"
            "wv" -> "wv"
            else -> "auto"
        }
    }

    private fun sanitizeVkAuthMode(mode: String?): String {
        return when (mode?.lowercase()) {
            MrttConstants.VkAuth.MODE_CAPTCHA -> MrttConstants.VkAuth.MODE_CAPTCHA
            MrttConstants.VkAuth.MODE_AUTO_JS -> MrttConstants.VkAuth.MODE_AUTO_JS
            else -> MrttConstants.VkAuth.MODE_CALLS
        }
    }

    private fun sanitizeSrtpMode(mode: String?): String {
        return when (mode?.lowercase()) {
            MrttConstants.SrtpMode.WRAP -> MrttConstants.SrtpMode.WRAP
            MrttConstants.SrtpMode.DTLS -> MrttConstants.SrtpMode.DTLS
            else -> MrttConstants.SrtpMode.AUTO
        }
    }

    private fun acquireWakeLock() {
        // «Экономия батареи» in force: the CPU may sleep, the tunnel with it — except for a deploy, which needs it awake
        if (BatterySaver.active.value && !DeployManager.isDeploying.value) return
        val now = SystemClock.elapsedRealtime()
        if (wakeLock?.isHeld == true && now < wakeLockExpiresAtElapsedMs - WAKE_LOCK_RENEWAL_WINDOW_MS) return
        if (wakeLock?.isHeld == true) wakeLock?.release()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "mrtt:tunnel_cpu"
        ).apply {
            setReferenceCounted(false)
            acquire(WAKE_LOCK_TIMEOUT_MS)
        }
        wakeLockExpiresAtElapsedMs = now + WAKE_LOCK_TIMEOUT_MS
    }

    @Suppress("DEPRECATION")
    private fun acquireWifiLock() {
        if (wifiLock?.isHeld == true) return
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager

        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "mrtt:wifi_perf").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        wakeLock = null
        wakeLockExpiresAtElapsedMs = 0L
    }

    private fun releaseWifiLock() {
        if (wifiLock?.isHeld == true) {
            wifiLock?.release()
        }
        wifiLock = null
    }

    private fun startStatsUpdater() {
        updateJob?.cancel()
        updateJob = serviceScope.launch(Dispatchers.Main) {
            var wasEverUp = TunnelManager.running.value || TunnelManager.processStartedAtMs > 0L
            val startedAt = SystemClock.elapsedRealtime()
            delay(1000)
            while (isActive) {
                val running = TunnelManager.running.value
                wasEverUp = wasEverUp || running || TunnelManager.processStartedAtMs > 0L
                if (running) {
                    acquireWakeLock()
                    acquireWifiLock()
                }
                if (
                    TunnelServicePolicy.shouldStop(
                        wasEverRunning = wasEverUp,
                        running = running,
                        elapsedMs = SystemClock.elapsedRealtime() - startedAt,
                        pausedForWifi = autoPausedForWifi,
                    )
                ) {
                    stopTunnel()
                    break
                }
                // The traffic numbers in the notification are read only with the screen on: redrawing it with the
                // screen off costs a notification post every few seconds for nothing. The next tick after the screen
                // comes on brings it up to date.
                if (screenInteractive()) updateNotification(currentNotificationText())
                delay(2000)
            }
        }
    }

    private fun currentNotificationText(): String {
        return buildTunnelNotificationText()
    }

    private fun buildTunnelNotificationText(): String {
        // В режиме скрытия уведомление не пересказывает подробности туннеля:
        // число потоков и объём трафика — это тоже отпечаток.
        if (SettingsStore.cachedHideTunnelFingerprint) return "MRTT"
        val statsText = TunnelManager.stats.value.trim()
        return when {
            statsText.isEmpty() -> "Туннель активен"
            statsText == "Ожидание данных..." -> "Туннель активен"
            else -> statsText
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            TUNNEL_NOTIFICATION_CHANNEL_ID,
            "MRTT Туннель",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Уведомление о работе туннеля"
            setShowBadge(false)

            lockscreenVisibility = if (SettingsStore.cachedHideTunnelFingerprint) {
                Notification.VISIBILITY_SECRET
            } else {
                Notification.VISIBILITY_PUBLIC
            }
            setSound(null, null)
            enableVibration(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun createNotification(text: String, actionName: String = "STOP", actionTitle: String = "Отключить"): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this, if (actionName == "STOP") 1 else 2,
            Intent(this, TunnelService::class.java).apply { action = actionName },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val restoreIntent = PendingIntent.getService(
            this, 3,
            Intent(this, TunnelService::class.java).apply { action = "RESTORE_NOTIFICATION" },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, TUNNEL_NOTIFICATION_CHANNEL_ID)
            .setContentTitle("MRTT")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_c)
            .setOngoing(true)
            .setLocalOnly(true)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_stop, actionTitle, stopIntent)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)

            .setVisibility(
                if (SettingsStore.cachedHideTunnelFingerprint) {
                    NotificationCompat.VISIBILITY_SECRET
                } else {
                    NotificationCompat.VISIBILITY_PUBLIC
                }
            )

            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOnlyAlertOnce(true) 
            .setSilent(true) 
            .setShowWhen(false)
            .setUsesChronometer(false)
            .setWhen(0L)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setDeleteIntent(restoreIntent)
            .build()
            .also {
                it.flags = it.flags or Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR or Notification.FLAG_FOREGROUND_SERVICE
            }
    }

    private fun startPersistentForeground(notification: Notification) {
        notification.flags = notification.flags or Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR or Notification.FLAG_FOREGROUND_SERVICE
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(TUNNEL_NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(TUNNEL_NOTIFICATION_ID, notification)
        }
        foregroundStarted = true
    }

    private fun updateNotification(text: String) {
        if (lastNotificationText == text && isNotificationVisible()) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (lastNotificationText != null &&
            now - lastNotificationPostElapsedMs < NOTIFICATION_MIN_REBUILD_INTERVAL_MS
        ) {
            return
        }
        lastNotificationText = text
        lastNotificationPostElapsedMs = now
        val notification = createNotification(text)
        if (foregroundStarted) {
            getSystemService(NotificationManager::class.java).notify(TUNNEL_NOTIFICATION_ID, notification)
        } else {
            startPersistentForeground(notification)
        }
    }

    private fun screenInteractive(): Boolean =
        runCatching { (getSystemService(POWER_SERVICE) as PowerManager).isInteractive }.getOrDefault(true)

    private fun isNotificationVisible(): Boolean {
        return runCatching {
            getSystemService(NotificationManager::class.java)
                .activeNotifications
                .any { it.id == TUNNEL_NOTIFICATION_ID }
        }.getOrDefault(false)
    }

    override fun onDestroy() {
        isStopping = true
        startJob?.cancel()
        startJob = null
        startGeneration++
        autoPauseSettingsJob?.cancel()
        autoPauseSettingsJob = null
        domainRoutingSettingsJob?.cancel()
        domainRoutingSettingsJob = null
        batterySaverJob?.cancel()
        batterySaverJob = null
        batteryReceiver?.let { receiver -> runCatching { unregisterReceiver(receiver) } }
        batteryReceiver = null
        BatterySaver.setActive(false)
        stopWifiAutoPauseWatch()
        updateJob?.cancel()
        networkSwapJob?.cancel()
        networkSwapJob = null
        networkLossJob?.cancel()
        networkLossJob = null
        vkRecoveryJob?.cancel()
        vkRecoveryJob = null
        synchronized(vkProbeLock) {
            vkProbeJobs.values.forEach(Job::cancel)
            vkProbeJobs.clear()
            physicalCandidates.clear()
        }
        releaseTunnelResources(finishVkCalls = true)
        if (foregroundStarted) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            foregroundStarted = false
        }
        serviceJob.cancel()
        networkCallback?.let { callback ->
            runCatching { connectivityManager.unregisterNetworkCallback(callback) }
        }
        networkCallback = null
        airplaneModeReceiver?.let { receiver ->
            runCatching { unregisterReceiver(receiver) }
        }
        airplaneModeReceiver = null
        physicalNetworks.clear()
        synchronized(wifiNetworkLock) {
            physicalWifiNetworks.clear()
        }
        TunnelManager.activeScope = TunnelManager.scope
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

private data class DomainRoutingUpdate(
    val enabled: Boolean,
    val excludeRuZones: Boolean,
    val templateDomains: Boolean,
    val directDomains: String,
)
