package com.mrtt.client

import android.content.Context
import android.content.pm.PackageManager
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import com.mrtt.client.ui.utils.parseMrttLink
import java.util.UUID
import org.json.JSONObject

private fun <T> Flow<T>.onIo(): Flow<T> = flowOn(Dispatchers.IO)

internal data class DeploySettingsSnapshot(
    val profile: Int = -1,
    val ip: String = "",
    val sshLogin: String = "",
    val sshPassword: String = "",
    val webLogin: String = "",
    val webPassword: String = "",
    val mainPassword: String = "",
    val sshPort: String = MrttConstants.Network.DEFAULT_SSH_PORT.toString(),
    val manualPortsEnabled: Boolean = false,
    val serverPeerPort: Int = MrttConstants.Network.DEFAULT_SERVER_PEER_PORT,
    val serverWebPort: Int = MrttConstants.Network.DEFAULT_SERVER_WEB_PORT,
    val sshKeysMode: Boolean = false,
    val dockerInstall: Boolean = false,
    val secretPathEnabled: Boolean = true,
    val secretPathUuid: String = "",
    val sshPrivateKey: String = "",
    val sshKeyPassphrase: String = "",
    val sshCertificate: String = "",
) {
    val isLoaded: Boolean
        get() = profile >= 0
}

internal data class TunnelAuthSnapshot(
    val profile: Int = -1,
    val connectionPassword: String = "",
    val connectionPasswordState: StoredSecretState = StoredSecretState.Missing,
    val mrttLink: String = "",
    val mrttLinkMode: Boolean = false,
) {
    val isLoaded: Boolean
        get() = profile >= 0
}

class SettingsStore(context: Context) {
    private val appContext = context.applicationContext
    companion object {
        private val Context.dataStore by preferencesDataStore("settings")
        private val ACTIVE_PROFILE = intPreferencesKey("active_profile")
        private val SHOW_SYSTEM_APPS = booleanPreferencesKey("show_system_apps")
        private val LOGGING_ENABLED = booleanPreferencesKey("logging_enabled")
        /** Скрывать порты и трафик туннеля от сторонних приложений. */
        private val HIDE_TUNNEL_FINGERPRINT = booleanPreferencesKey("hide_tunnel_fingerprint")
        private val INFO_ACTIONS_EXPANDED = booleanPreferencesKey("info_actions_expanded")
        private val INFO_PROJECT_EXPANDED = booleanPreferencesKey("info_project_expanded")
        private val MRTT_LINK = stringPreferencesKey("mrtt_link")
        private val MRTT_LINK_MODE = booleanPreferencesKey("mrtt_link_mode")
        private val PARTICIPANT_SHOW_LOGS = booleanPreferencesKey("participant_show_logs")
        private val VPS_SERVERS = stringPreferencesKey("vps_servers")
        private val VPS_SERVERS_MIGRATED = booleanPreferencesKey("vps_servers_migrated")
        private val CONNECTION_PROFILES = stringPreferencesKey("connection_profiles")
        private val CONNECTION_PROFILES_MIGRATED = booleanPreferencesKey("connection_profiles_migrated")
        private val ACTIVE_CONNECTION_PROFILE = stringPreferencesKey("active_connection_profile")

        private val PEER = stringPreferencesKey("peer")
        private val VK_HASHES = stringPreferencesKey("vk_hashes")
        private val SECONDARY_VK_HASH = stringPreferencesKey("secondary_vk_hash")
        private val WORKERS_PER_HASH = intPreferencesKey("workers_per_hash")
        private val PROTOCOL = stringPreferencesKey("protocol")
        private val LISTEN_PORT = intPreferencesKey("listen_port")
        private val MANUAL_PORTS_ENABLED = booleanPreferencesKey("manual_ports_enabled")
        private val SERVER_PEER_PORT = intPreferencesKey("server_peer_port")
        private val SNI = stringPreferencesKey("sni")
        private val NO_DNS = booleanPreferencesKey("no_dns")
        private val CUSTOM_TURN_IPS = stringPreferencesKey("custom_turn_ips")
        private val SELECTED_TURN_SUBNET = stringPreferencesKey("selected_turn_subnet")
        private val TURN_SUBNET_IP_LIMIT = stringPreferencesKey("turn_subnet_ip_limit")

        private val USER_AGENT = stringPreferencesKey("user_agent")
        private val PROFILE_NAME = stringPreferencesKey("profile_name")

        private val DEPLOY_IP = stringPreferencesKey("deploy_ip")
        private val DEPLOY_LOGIN = stringPreferencesKey("deploy_login")
        private val DEPLOY_PASSWORD = stringPreferencesKey("deploy_password")
        private val DEPLOY_PASSWORD_ENCRYPTED = stringPreferencesKey("deploy_password_encrypted")
        private val DEPLOY_SSH_PORT = stringPreferencesKey("deploy_ssh_port")
        private val SSH_KEYS_MODE = booleanPreferencesKey("ssh_keys_mode")
        private val DOCKER_INSTALL = booleanPreferencesKey("docker_install")
        private val DEPLOY_SECRET_PATH_ENABLED = booleanPreferencesKey("deploy_secret_path_enabled")
        private val DEPLOY_SECRET_PATH_UUID = stringPreferencesKey("deploy_secret_path_uuid")
        private val SSH_PRIVATE_KEY = stringPreferencesKey("ssh_private_key")
        private val SSH_PRIVATE_KEY_ENCRYPTED = stringPreferencesKey("ssh_private_key_encrypted")
        private val SSH_KEY_PASSPHRASE = stringPreferencesKey("ssh_key_passphrase")
        private val SSH_KEY_PASSPHRASE_ENCRYPTED = stringPreferencesKey("ssh_key_passphrase_encrypted")
        private val SSH_CERTIFICATE = stringPreferencesKey("ssh_certificate")
        private val SSH_CERTIFICATE_ENCRYPTED = stringPreferencesKey("ssh_certificate_encrypted")
        private val EXCLUDED_APPS = stringPreferencesKey("excluded_apps")
        private val WHITELIST_APPS = stringPreferencesKey("whitelist_apps")

        /** Приложения, которым разрешён прямой выход: «свой интернет», но с фильтром. */
        private val APP_DIRECT_FILTERED = stringPreferencesKey("app_direct_filtered")
        private val APP_DIRECT_RAW = stringPreferencesKey("app_direct_raw")

        private val DETAILED_LOGS = booleanPreferencesKey("detailed_logs")

        private val CONNECTION_PASSWORD = stringPreferencesKey("connection_password")
        private val CONNECTION_PASSWORD_ENCRYPTED = stringPreferencesKey("connection_password_encrypted")
        private val CONNECTION_PASSWORD_LOCAL = stringPreferencesKey("connection_password_local")
        private val DEPLOY_MAIN_PASSWORD = stringPreferencesKey("deploy_main_password")
        private val DEPLOY_MAIN_PASSWORD_ENCRYPTED = stringPreferencesKey("deploy_main_password_encrypted")
        private val DEPLOY_WEB_LOGIN = stringPreferencesKey("deploy_web_login")
        private val DEPLOY_WEB_PASSWORD = stringPreferencesKey("deploy_web_password")
        private val DEPLOY_WEB_PASSWORD_ENCRYPTED = stringPreferencesKey("deploy_web_password_encrypted")
        private val SERVER_WEB_PORT = intPreferencesKey("server_web_port")

        private val PROXY_MODE = stringPreferencesKey("proxy_mode") 
        private val PROXY_HOST = stringPreferencesKey("proxy_host")
        private val PROXY_PORT = intPreferencesKey("proxy_port")

        private val VK_AUTH_MODE = stringPreferencesKey("vk_auth_mode") 
        private val OBFS_MODE = stringPreferencesKey("obfs_mode") 
        private val TURN_TRANSPORT = stringPreferencesKey("turn_transport")
        private val SRTP_MODE = stringPreferencesKey("srtp_mode")
        private val CAPTCHA_MODE = stringPreferencesKey("captcha_mode")
        private val CAPTCHA_SOLVE_METHOD = stringPreferencesKey("captcha_solve_method") 
        private val CAPTCHA_WBV_SOLVE_METHOD = stringPreferencesKey("captcha_wbv_solve_method") 

        private val VK_HASH_MODE = stringPreferencesKey("vk_hash_mode")
        private val VK_ACCESS_TOKEN = stringPreferencesKey("vk_access_token")
        private const val VK_SESSION_PREFIX = "vkweb:"
        /** Вход через приложение ВК (VK ID): храним не куки, а сам токен. */
        private const val VK_ID_TOKEN_PREFIX = "vkid:"
        private val VK_ID_REFRESH_TOKEN = stringPreferencesKey("vk_id_refresh_token")
        private val VK_ID_REFRESH_TOKEN_ENCRYPTED = stringPreferencesKey("vk_id_refresh_token_encrypted")
        private val VK_ACCESS_TOKEN_ENCRYPTED = stringPreferencesKey("vk_access_token_encrypted")
        private val VK_ACCESS_TOKEN_USER_ID = stringPreferencesKey("vk_access_token_user_id")
        private val MAX_GROUP_ID = stringPreferencesKey("max_group_id")
        /** deviceId страницы web.max.ru: MAX привязывает токен к устройству. */
        private val MAX_DEVICE_ID = stringPreferencesKey("max_device_id")
        private val TRANSPORT_MODE = stringPreferencesKey("transport_mode")
        private val JITSI_ROOM_OVERRIDE = stringPreferencesKey("jitsi_room_override")
        private val JITSI_WORKERS = intPreferencesKey("jitsi_workers")
        private val PING_URL = stringPreferencesKey("ping_url")
        const val DEFAULT_PING_URL = "https://www.google.com/generate_204"
        private val MAX_ACCESS_TOKEN = stringPreferencesKey("max_access_token")
        private val MAX_ACCESS_TOKEN_ENCRYPTED = stringPreferencesKey("max_access_token_encrypted")

        private val IS_WHITELIST = booleanPreferencesKey("is_whitelist")
        private val VK_PREFER_LINK_HASHES = booleanPreferencesKey("vk_prefer_link_hashes")
        private val SPLIT_TUNNEL_WHITELIST_MIGRATED = booleanPreferencesKey("split_tunnel_whitelist_migrated")
        private val EXTRA_WORKERS = booleanPreferencesKey("extra_workers")
        private val AUTO_JS_RISK_ACKNOWLEDGED = booleanPreferencesKey("auto_js_risk_acknowledged")
        private val TCP_TRANSPORT_RISK_ACKNOWLEDGED = booleanPreferencesKey("tcp_transport_risk_acknowledged")
        private val MAX_TRANSPORT_RISK_ACKNOWLEDGED = booleanPreferencesKey("max_transport_risk_acknowledged")
        private val BATTERY_OPTIMIZATION_PROMPT_HANDLED =
            booleanPreferencesKey("battery_optimization_prompt_handled")
        private val AUTO_PAUSE_ON_WIFI = booleanPreferencesKey("auto_pause_on_wifi")

        /** Включать туннель при открытии приложения, если пользователь сам его выключил. */
        private val AUTO_CONNECT_ON_LAUNCH = booleanPreferencesKey("auto_connect_on_launch")
        private val BATTERY_SAVER_MODE = stringPreferencesKey("battery_saver_mode")
        private val BATTERY_SAVER_PERCENT = intPreferencesKey("battery_saver_percent")
        private val DOMAIN_ROUTING_ENABLED = booleanPreferencesKey("domain_routing_enabled")
        private val DOMAIN_IS_WHITELIST = booleanPreferencesKey("domain_is_whitelist")
        private val EXCLUDE_RU_ZONES_ENABLED = booleanPreferencesKey("exclude_ru_zones_enabled")
        private val TEMPLATE_DOMAINS_ENABLED = booleanPreferencesKey("template_domains_enabled")
        private val ADBLOCK_ENABLED = booleanPreferencesKey("adblock_enabled")
        /** Свои домены Adblock: по одному в строке, `@@домен` — исключение. */
        private val ADBLOCK_DOMAINS = stringPreferencesKey("adblock_domains")
        /** Подписки на списки трекеров: JSON-массив адресов. */
        private val ADBLOCK_SUBSCRIPTIONS = stringPreferencesKey("adblock_subscriptions")
        /** Включённые категории правил (geosite-category-ru@ads и т.п.), через запятую. */
        private val ADBLOCK_CATEGORIES = stringPreferencesKey("adblock_categories")
        /** Российские сервисы (geosite-category-ru) идут напрямую, мимо туннеля. */
        private val GEOSITE_RU_ENABLED = booleanPreferencesKey("geosite_ru_enabled")
        /** Скрытие через root: закрыть localhost чужим приложениям и спрятать процесс. */
        internal val PORT_HIDE_ROOT = booleanPreferencesKey("port_hide_root")
        /** Пакеты, которым закрыт localhost в режиме скрытия через root. */
        internal val PORT_HIDE_PACKAGES = stringPreferencesKey("port_hide_packages")
        private val GAME_MODE_ENABLED = booleanPreferencesKey("game_mode_enabled")
        private val GAME_MODE_AUTO = booleanPreferencesKey("game_mode_auto")
        private val GAME_PACKAGES = stringPreferencesKey("game_packages")
        private val GAME_EXTRA_PORTS = stringPreferencesKey("game_extra_ports")

        /** Игры, которые пользователь явно вернул в туннель. */
        private val GAME_TUNNEL_PACKAGES = stringPreferencesKey("game_tunnel_packages")
        private val GAME_AUTO_ACTIVE = booleanPreferencesKey("game_auto_active")
        private val OWN_SERVER_IPS = stringPreferencesKey("own_server_ips")
        private val DIRECT_DOMAINS = stringPreferencesKey("direct_domains")
        private val DIRECT_DOMAINS_BLACK = stringPreferencesKey("direct_domains_black")
        private val DIRECT_DOMAINS_WHITE = stringPreferencesKey("direct_domains_white")

        private val IP_ROUTING_ENABLED = booleanPreferencesKey("ip_routing_enabled")
        private val IP_IS_WHITELIST = booleanPreferencesKey("ip_is_whitelist")
        private val DIRECT_IPS_BLACK = stringPreferencesKey("direct_ips_black")
        private val DIRECT_IPS_WHITE = stringPreferencesKey("direct_ips_white")

        private val TUNNEL_MTU = intPreferencesKey("tunnel_mtu")

        private val THEME_MODE = stringPreferencesKey("theme_mode") 
        private val IS_DYNAMIC_COLOR = booleanPreferencesKey("is_dynamic_color")
        private val THEME_PALETTE = stringPreferencesKey("theme_palette")

        private val SELECTED_FINGERPRINT = stringPreferencesKey("selected_fingerprint")
        private val ACTIVE_CLIENT_IDS = stringPreferencesKey("active_client_ids")

        private val UPDATE_LAST_CHECK_AT = longPreferencesKey("update_last_check_at")
        private val UPDATE_LATEST_VERSION = stringPreferencesKey("update_latest_version")
        private val UPDATE_LAST_ERROR = stringPreferencesKey("update_last_error")
        private val UPDATE_CHECK_INTERVAL_HOURS = intPreferencesKey("update_check_interval_hours")
        private val UPDATE_POSTPONE_UNTIL = longPreferencesKey("update_postpone_until")
        private val UPDATE_POSTPONE_VERSION = stringPreferencesKey("update_postpone_version")
        private val UPDATE_DIALOG_LAST_SHOWN_VERSION = stringPreferencesKey("update_dialog_last_shown_version")
        private val UPDATE_DIALOG_LAST_SHOWN_AT = longPreferencesKey("update_dialog_last_shown_at")
        private val UPDATE_DIALOG_LAST_ACTION_VERSION = stringPreferencesKey("update_dialog_last_action_version")
        private val UPDATE_DIALOG_LAST_ACTION = stringPreferencesKey("update_dialog_last_action")
        private val UPDATE_DIALOG_LAST_ACTION_AT = longPreferencesKey("update_dialog_last_action_at")

        private val CLIENT_ID_CHECK_RESULTS = stringPreferencesKey("client_id_check_results")
        private val VK_HASH_CHECK_RESULTS = stringPreferencesKey("vk_hash_check_results")
        private val CONNECTION_GENERATION = longPreferencesKey("connection_generation")
        private val TUNNEL_LAST_DIAGNOSTIC = stringPreferencesKey("tunnel_last_diagnostic")
        private val TUNNEL_LAST_DIAGNOSTIC_AT = longPreferencesKey("tunnel_last_diagnostic_at")
        private val TUNNEL_WAS_RUNNING = booleanPreferencesKey("tunnel_was_running")

        @Volatile
        internal var cachedVkHashMode: String? = null

        @Volatile
        internal var cachedVkSession: String? = null

        /** Токен входа через приложение ВК (VK ID): тоже кэш, чтобы не ходить в DataStore. */
        @Volatile
        internal var cachedVkIdToken: String? = null

        @Volatile
        internal var cachedObfsMode: String? = null

        /** Скрытие портов и трафика: нужно службе туннеля без suspend-вызова. */
        @Volatile
        internal var cachedHideTunnelFingerprint: Boolean = false

        @Volatile
        internal var cachedTurnTransport: String? = null

        @Volatile
        internal var cachedSrtpMode: String? = null

        @Volatile
        internal var cachedMrttLinkMode: Boolean? = null

        @Volatile
        internal var cachedWorkersPerHash: Int? = null

        @Volatile
        internal var cachedManualPortsEnabled: Boolean? = null

        @Volatile
        internal var cachedServerPeerPort: Int? = null

        @Volatile
        internal var cachedExtraWorkers: Boolean? = null

        @Volatile
        internal var cachedCustomTurnIps: String? = null

        @Volatile
        internal var cachedExcludedApps: String? = null

        @Volatile
        internal var cachedWhitelistApps: String? = null

        /** Приложения в режиме «напрямую с фильтром рекламы». */
        @Volatile
        internal var cachedAppDirectFiltered: String = ""

        /** Приложения, полностью исключённые из VPN (напрямую и без фильтра). */
        @Volatile
        internal var cachedAppDirectRaw: String = ""

        @Volatile
        internal var cachedIsWhitelist: Boolean? = null

        @Volatile
        internal var cachedDomainRoutingEnabled: Boolean? = null

        @Volatile
        internal var cachedDomainIsWhitelist: Boolean? = null

        @Volatile
        internal var cachedExcludeRuZonesEnabled: Boolean? = null

        @Volatile
        internal var cachedTemplateDomainsEnabled: Boolean? = null

        @Volatile
        internal var cachedDirectDomains: String? = null

        @Volatile
        internal var cachedDirectDomainsBlack: String? = null

        @Volatile
        internal var cachedDirectDomainsWhite: String? = null

        @Volatile
        internal var cachedIpRoutingEnabled: Boolean? = null

        @Volatile
        internal var cachedIpIsWhitelist: Boolean? = null

        @Volatile
        internal var cachedDirectIpsBlack: String? = null

        @Volatile
        internal var cachedDirectIpsWhite: String? = null

        @Volatile
        internal var cachedGameModeEnabled: Boolean? = null

        @Volatile
        internal var cachedGameModeAuto: Boolean? = null

        /** Адреса своих серверов, доступные без suspend-вызова (кэш из DataStore). */
        @Volatile
        internal var cachedOwnServerIps: String = ""

        /** Токен VK-аккаунта сервера из активной ссылки: нужен без suspend-вызова. */
        @Volatile
        internal var cachedLinkVkToken: String = ""

        private val uiCacheStarted = java.util.concurrent.atomic.AtomicBoolean(false)
        private val migrationsStarted = java.util.concurrent.atomic.AtomicBoolean(false)

        private fun <T> getProfileKey(baseKey: Preferences.Key<T>, profile: Int): Preferences.Key<T> {
            if (profile == 0) return baseKey
            val newName = "${baseKey.name}_$profile"
            @Suppress("UNCHECKED_CAST")
            return when (baseKey) {
                PEER, VK_HASHES, SECONDARY_VK_HASH, PROTOCOL, SNI, USER_AGENT, DEPLOY_IP, DEPLOY_LOGIN, DEPLOY_PASSWORD, DEPLOY_PASSWORD_ENCRYPTED, DEPLOY_SSH_PORT, EXCLUDED_APPS, WHITELIST_APPS, DIRECT_DOMAINS, DIRECT_DOMAINS_BLACK, DIRECT_DOMAINS_WHITE, DIRECT_IPS_BLACK, DIRECT_IPS_WHITE, GAME_PACKAGES, GAME_EXTRA_PORTS, CONNECTION_PASSWORD, CONNECTION_PASSWORD_ENCRYPTED, CONNECTION_PASSWORD_LOCAL, DEPLOY_MAIN_PASSWORD, DEPLOY_MAIN_PASSWORD_ENCRYPTED, DEPLOY_WEB_LOGIN, DEPLOY_WEB_PASSWORD, DEPLOY_WEB_PASSWORD_ENCRYPTED, PROXY_MODE, PROXY_HOST, VK_AUTH_MODE, OBFS_MODE, TURN_TRANSPORT, SRTP_MODE, CAPTCHA_MODE, CAPTCHA_SOLVE_METHOD, CAPTCHA_WBV_SOLVE_METHOD, MRTT_LINK, SELECTED_FINGERPRINT, ACTIVE_CLIENT_IDS, VK_HASH_MODE, VK_ACCESS_TOKEN, VK_ACCESS_TOKEN_ENCRYPTED, VK_ACCESS_TOKEN_USER_ID, SSH_PRIVATE_KEY, SSH_PRIVATE_KEY_ENCRYPTED, SSH_KEY_PASSPHRASE, SSH_KEY_PASSPHRASE_ENCRYPTED, SSH_CERTIFICATE, SSH_CERTIFICATE_ENCRYPTED, VK_HASH_CHECK_RESULTS, CLIENT_ID_CHECK_RESULTS, CUSTOM_TURN_IPS, SELECTED_TURN_SUBNET -> stringPreferencesKey(newName) as Preferences.Key<T>
                WORKERS_PER_HASH, LISTEN_PORT, SERVER_PEER_PORT, PROXY_PORT, SERVER_WEB_PORT -> intPreferencesKey(newName) as Preferences.Key<T>
                MANUAL_PORTS_ENABLED, NO_DNS, IS_WHITELIST, MRTT_LINK_MODE, DETAILED_LOGS, HIDE_TUNNEL_FINGERPRINT, SSH_KEYS_MODE, DOCKER_INSTALL, EXTRA_WORKERS, SPLIT_TUNNEL_WHITELIST_MIGRATED, DOMAIN_ROUTING_ENABLED, DOMAIN_IS_WHITELIST, EXCLUDE_RU_ZONES_ENABLED, TEMPLATE_DOMAINS_ENABLED, IP_ROUTING_ENABLED, IP_IS_WHITELIST, GAME_MODE_ENABLED, GAME_MODE_AUTO, GAME_AUTO_ACTIVE -> booleanPreferencesKey(newName) as Preferences.Key<T>
                CONNECTION_GENERATION -> longPreferencesKey(newName) as Preferences.Key<T>
                else -> stringPreferencesKey(newName) as Preferences.Key<T>
            }
        }
    }

    private val dataStore = appContext.dataStore
    private val secureStore = SecureStringStore(appContext)

    val activeProfile: Flow<Int> = dataStore.data.map {
        (it[ACTIVE_PROFILE] ?: MrttConstants.Profiles.MIN_INDEX).coerceIn(
            MrttConstants.Profiles.MIN_INDEX,
            MrttConstants.Profiles.MAX_INDEX,
        )
    }
    val tunnelLastDiagnostic: Flow<String> = dataStore.data.map {
        it[TUNNEL_LAST_DIAGNOSTIC] ?: ""
    }
    val showSystemApps: Flow<Boolean> = dataStore.data.map { it[SHOW_SYSTEM_APPS] ?: false }
    val loggingEnabled: Flow<Boolean> = dataStore.data.map { it[LOGGING_ENABLED] ?: true }

    /**
     * Скрытие портов и трафика от сторонних приложений. По умолчанию выключено:
     * маскировка стоит лишних байт в каждом пакете.
     */
    val hideTunnelFingerprint: Flow<Boolean> = dataStore.data.map { it[HIDE_TUNNEL_FINGERPRINT] ?: false }
    val infoActionsExpanded: Flow<Boolean> = dataStore.data.map { it[INFO_ACTIONS_EXPANDED] ?: false }
    val infoProjectExpanded: Flow<Boolean> = dataStore.data.map { it[INFO_PROJECT_EXPANDED] ?: false }
    val mrttLink: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(MRTT_LINK, profile)] ?: ""
    }
    /**
     * Подключение по ссылке выбранного профиля. По умолчанию включено (профиль — это
     * и есть ссылка), но значение читается из настроек: иначе режим нельзя было
     * выключить, и приложение требовало ссылку даже там, где она не нужна.
     */
    val mrttLinkMode: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(MRTT_LINK_MODE, profile)] ?: true
    }
    val vpsServersJson: Flow<String> = dataStore.data.map { it[VPS_SERVERS] ?: "[]" }
    val connectionProfilesJson: Flow<String> = dataStore.data.map { it[CONNECTION_PROFILES] ?: "[]" }
    val activeConnectionProfileId: Flow<String> = dataStore.data.map { it[ACTIVE_CONNECTION_PROFILE] ?: "" }

    val peer: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(PEER, profile)] ?: ""
    }
    val vkHashes: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(VK_HASHES, profile)] ?: ""
    }
    val secondaryVkHash: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(SECONDARY_VK_HASH, profile)] ?: ""
    }
    val workersPerHash: Flow<Int> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        val current = prefs[getProfileKey(WORKERS_PER_HASH, profile)] ?: MrttConstants.Tunnel.DEFAULT_WORKERS
        WorkerCountPolicy.normalize(current)
    }
    val protocol: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(PROTOCOL, profile)] ?: "udp"
    }
    val listenPort: Flow<Int> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(LISTEN_PORT, profile)] ?: 0
    }
    val manualPortsEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(MANUAL_PORTS_ENABLED, profile)] ?: false
    }
    val serverPeerPort: Flow<Int> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(SERVER_PEER_PORT, profile)] ?: MrttConstants.Network.DEFAULT_SERVER_PEER_PORT
    }
    val sni: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(SNI, profile)] ?: ""
    }
    val tunnelMtu: Flow<Int> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        (prefs[getProfileKey(TUNNEL_MTU, profile)] ?: MrttConstants.Vpn.DEFAULT_MTU)
            .coerceIn(MrttConstants.Vpn.MTU_MIN, MrttConstants.Vpn.MTU_MAX)
    }

    val deployIp: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DEPLOY_IP, profile)] ?: ""
    }
    val deployLogin: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DEPLOY_LOGIN, profile)] ?: ""
    }
    val deployPassword: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        readSecret(prefs, DEPLOY_PASSWORD_ENCRYPTED, DEPLOY_PASSWORD, profile)
    }.onIo()
    val deploySshPort: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DEPLOY_SSH_PORT, profile)] ?: ""
    }
    internal val deploySettingsSnapshot: Flow<DeploySettingsSnapshot> = dataStore.data.map { prefs ->
        readDeploySnapshot(prefs, prefs[ACTIVE_PROFILE] ?: 0)
    }.onIo()

    private fun readDeploySnapshot(prefs: Preferences, profile: Int): DeploySettingsSnapshot =
        DeploySettingsSnapshot(
            profile = profile,
            ip = prefs[getProfileKey(DEPLOY_IP, profile)] ?: "",
            sshLogin = prefs[getProfileKey(DEPLOY_LOGIN, profile)] ?: "",
            sshPassword = readSecret(prefs, DEPLOY_PASSWORD_ENCRYPTED, DEPLOY_PASSWORD, profile),
            webLogin = prefs[getProfileKey(DEPLOY_WEB_LOGIN, profile)] ?: "",
            webPassword = readSecret(prefs, DEPLOY_WEB_PASSWORD_ENCRYPTED, DEPLOY_WEB_PASSWORD, profile),
            mainPassword = readSecret(prefs, DEPLOY_MAIN_PASSWORD_ENCRYPTED, DEPLOY_MAIN_PASSWORD, profile),
            sshPort = prefs[getProfileKey(DEPLOY_SSH_PORT, profile)]
                ?.ifBlank { MrttConstants.Network.DEFAULT_SSH_PORT.toString() }
                ?: MrttConstants.Network.DEFAULT_SSH_PORT.toString(),
            manualPortsEnabled = prefs[getProfileKey(MANUAL_PORTS_ENABLED, profile)] ?: false,
            serverPeerPort = prefs[getProfileKey(SERVER_PEER_PORT, profile)]
                ?: MrttConstants.Network.DEFAULT_SERVER_PEER_PORT,
            serverWebPort = prefs[getProfileKey(SERVER_WEB_PORT, profile)]
                ?: MrttConstants.Network.DEFAULT_SERVER_WEB_PORT,
            sshKeysMode = prefs[getProfileKey(SSH_KEYS_MODE, profile)] ?: false,
            dockerInstall = prefs[getProfileKey(DOCKER_INSTALL, profile)] ?: false,
            secretPathEnabled = true,
            secretPathUuid = prefs[getProfileKey(DEPLOY_SECRET_PATH_UUID, profile)] ?: "",
            sshPrivateKey = readSecret(prefs, SSH_PRIVATE_KEY_ENCRYPTED, SSH_PRIVATE_KEY, profile),
            sshKeyPassphrase = readSecret(prefs, SSH_KEY_PASSPHRASE_ENCRYPTED, SSH_KEY_PASSPHRASE, profile),
            sshCertificate = readSecret(prefs, SSH_CERTIFICATE_ENCRYPTED, SSH_CERTIFICATE, profile),
        )
    internal val tunnelAuthSnapshot: Flow<TunnelAuthSnapshot> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        val connectionPassword = readConnectionPasswordState(prefs, profile)
        TunnelAuthSnapshot(
            profile = profile,
            connectionPassword = connectionPassword.value,
            connectionPasswordState = connectionPassword.state,
            mrttLink = prefs[getProfileKey(MRTT_LINK, profile)] ?: "",
            mrttLinkMode = prefs[getProfileKey(MRTT_LINK_MODE, profile)] ?: true,
        )
    }.onIo()
    val excludedApps: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(EXCLUDED_APPS, profile)] ?: ""
    }
    val whitelistApps: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(WHITELIST_APPS, profile)] ?: ""
    }

    /**
     * Приложения, которым разрешён прямой выход через интернет пользователя с
     * сохранением DNS-фильтра рекламы. Третий режим рядом с «в туннеле» и
     * «исключено»: приложение остаётся под VPN, реклама режется, а трафик
     * не идёт через звонок.
     */
    val appDirectFiltered: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(APP_DIRECT_FILTERED, profile)] ?: ""
    }

    /** Приложения, полностью исключённые из VPN: свой интернет без фильтра. */
    val appDirectRaw: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(APP_DIRECT_RAW, profile)] ?: ""
    }

    internal val connectionPasswordState: Flow<StoredSecret> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        readConnectionPasswordState(prefs, profile)
    }.onIo()
    val connectionPassword: Flow<String> = connectionPasswordState.map { it.value }
    val deployMainPassword: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        readSecret(prefs, DEPLOY_MAIN_PASSWORD_ENCRYPTED, DEPLOY_MAIN_PASSWORD, profile)
    }.onIo()
    val deployWebLogin: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DEPLOY_WEB_LOGIN, profile)] ?: ""
    }
    val deployWebPassword: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        readSecret(prefs, DEPLOY_WEB_PASSWORD_ENCRYPTED, DEPLOY_WEB_PASSWORD, profile)
    }.onIo()
    val serverWebPort: Flow<Int> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(SERVER_WEB_PORT, profile)] ?: MrttConstants.Network.DEFAULT_SERVER_WEB_PORT
    }

    val vkAuthMode: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        when (prefs[getProfileKey(VK_AUTH_MODE, profile)]) {
            MrttConstants.VkAuth.MODE_CAPTCHA -> MrttConstants.VkAuth.MODE_CAPTCHA
            MrttConstants.VkAuth.MODE_AUTO_JS -> MrttConstants.VkAuth.MODE_AUTO_JS
            else -> MrttConstants.VkAuth.MODE_CALLS
        }
    }
    val obfsMode: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        val mode = prefs[getProfileKey(OBFS_MODE, profile)]
        if (mode == "unified") {
            mode
        } else {
            MrttConstants.Tunnel.DEFAULT_OBFS_MODE
        }
    }

    val turnTransport: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        when (prefs[getProfileKey(TURN_TRANSPORT, profile)]) {
            MrttConstants.Tunnel.TURN_TRANSPORT_TCP_TLS -> MrttConstants.Tunnel.TURN_TRANSPORT_TCP_TLS
            else -> MrttConstants.Tunnel.DEFAULT_TURN_TRANSPORT
        }
    }

    val srtpMode: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        when (prefs[getProfileKey(SRTP_MODE, profile)]) {
            MrttConstants.SrtpMode.WRAP -> MrttConstants.SrtpMode.WRAP
            MrttConstants.SrtpMode.DTLS -> MrttConstants.SrtpMode.DTLS
            else -> MrttConstants.SrtpMode.DEFAULT
        }
    }

    val customTurnIps: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        val subnetId = prefs[getProfileKey(SELECTED_TURN_SUBNET, profile)] ?: ""
        if (subnetId.isNotBlank()) {
            val stored = prefs[getProfileKey(CUSTOM_TURN_IPS, profile)]
            if (!stored.isNullOrBlank()) {
                stored
            } else {
                TurnSubnetRegistry.getJoinedIpsForSubnet(subnetId)
            }
        } else {
            ""
        }
    }

    val selectedTurnSubnet: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(SELECTED_TURN_SUBNET, profile)] ?: ""
    }

    val turnSubnetIpLimit: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(TURN_SUBNET_IP_LIMIT, profile)] ?: "ALL"
    }

    val captchaMode: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(CAPTCHA_MODE, profile)] ?: "auto"
    }
    val captchaSolveMethod: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(CAPTCHA_SOLVE_METHOD, profile)] ?: "auto"
    }
    val captchaWbvSolveMethod: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(CAPTCHA_WBV_SOLVE_METHOD, profile)] ?: "auto"
    }

    val vkHashMode: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        val mode = prefs[getProfileKey(VK_HASH_MODE, profile)]
        when (mode) {
            "auto", MrttConstants.VkAutoHash.MODE_AUTO_API ->
                MrttConstants.VkAutoHash.MODE_AUTO_API
            MrttConstants.VkAutoHash.MODE_AUTO_JS ->
                MrttConstants.VkAutoHash.MODE_AUTO_JS
            else -> MrttConstants.VkAutoHash.MODE_MANUAL
        }
    }
    /** Куки сессии VK после входа через WebView; токен из них получается только на время подключения. */
    val vkSession: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        readVkSession(prefs, profile)
    }.onIo()

    /** Вход через приложение ВК сохранён: привязкой стала пара токенов, а не куки. */
    val vkIdToken: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        readVkIdToken(prefs, profile)
    }.onIo()

    /** `refresh_token` для входа через приложение ВК (может быть пустым). */
    val vkIdRefreshToken: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        readSecret(prefs, VK_ID_REFRESH_TOKEN_ENCRYPTED, VK_ID_REFRESH_TOKEN, profile)
    }.onIo()
    val maxGroupId: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(MAX_GROUP_ID, profile)] ?: ""
    }.onIo()
    val maxAccessToken: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        readSecret(prefs, MAX_ACCESS_TOKEN_ENCRYPTED, MAX_ACCESS_TOKEN, profile)
    }.onIo()
    val maxDeviceId: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(MAX_DEVICE_ID, profile)] ?: ""
    }.onIo()

    val transportMode: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        when (prefs[getProfileKey(TRANSPORT_MODE, profile)]) {
            MrttConstants.Transport.MODE_MAX -> MrttConstants.Transport.MODE_MAX
            MrttConstants.Transport.MODE_JITSI -> MrttConstants.Transport.MODE_JITSI
            else -> MrttConstants.Transport.MODE_VK
        }
    }.onIo()


    /** Своя комната Jitsi вместо комнаты из ссылки профиля; пусто — берётся из ссылки. */
    val jitsiRoomOverride: Flow<String> = dataStore.data.map { prefs -> prefs[JITSI_ROOM_OVERRIDE].orEmpty() }.onIo()

    suspend fun saveJitsiRoomOverride(room: String) {
        dataStore.edit { prefs -> prefs[JITSI_ROOM_OVERRIDE] = room }
    }

    /** Воркеры Jitsi: каждый становится участником комнаты, поэтому их не больше, чем мест у сервера. */
    val jitsiWorkers: Flow<Int> = dataStore.data.map { prefs ->
        clampJitsiWorkers(prefs[JITSI_WORKERS] ?: MrttConstants.Tunnel.DEFAULT_JITSI_WORKERS)
    }.onIo()

    /** Адрес проверки задержки в «Профилях», как URL-тест в клиентах. */
    val pingUrl: Flow<String> = dataStore.data.map { prefs -> prefs[PING_URL]?.takeIf { it.isNotBlank() } ?: DEFAULT_PING_URL }.onIo()

    suspend fun savePingUrl(url: String) {
        dataStore.edit { prefs -> prefs[PING_URL] = url.trim() }
    }

    suspend fun saveJitsiWorkers(workers: Int) {
        dataStore.edit { prefs -> prefs[JITSI_WORKERS] = clampJitsiWorkers(workers) }
    }

    val vkAccessTokenUserId: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(VK_ACCESS_TOKEN_USER_ID, profile)] ?: ""
    }

    /** Хеши из ссылки вместо своего аккаунта VK. По умолчанию свой привязанный VK важнее. */
    val vkPreferLinkHashes: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(VK_PREFER_LINK_HASHES, profile)] ?: false
    }.onIo()

    suspend fun saveVkPreferLinkHashes(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(VK_PREFER_LINK_HASHES, profile)] = enabled
        }
    }

    val isWhitelist: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(IS_WHITELIST, profile)] ?: false
    }

    val domainRoutingEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DOMAIN_ROUTING_ENABLED, profile)] ?: false
    }

    val excludeRuZonesEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(EXCLUDE_RU_ZONES_ENABLED, profile)] ?: false
    }

    val templateDomainsEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(TEMPLATE_DOMAINS_ENABLED, profile)] ?: false
    }

    /** DNS-фильтр рекламы: включён независимо от маршрутизации доменов. */
    val adblockEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(ADBLOCK_ENABLED, profile)] ?: false
    }

    /** Свои домены Adblock (по одному в строке, `@@домен` — исключение). */
    val adblockDomains: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(ADBLOCK_DOMAINS, profile)] ?: ""
    }

    /** Подписки Adblock: JSON-массив адресов и подписей. */
    val adblockSubscriptions: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(ADBLOCK_SUBSCRIPTIONS, profile)] ?: ""
    }

    /** Включённые категории правил (geosite-category-ru@ads/@telemetry/@cn), через запятую. */
    val adblockCategories: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(ADBLOCK_CATEGORIES, profile)] ?: ""
    }

    /** Российские сервисы (geosite-category-ru) открываются напрямую, мимо туннеля. */
    val geositeRuEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(GEOSITE_RU_ENABLED, profile)] ?: false
    }

    /**
     * Скрытие через root: порт VPN закрывается для чужих приложений на уровне
     * iptables, а процесс клиента перестаёт быть виден по имени. Без root
     * настройка ничего не включает — остаётся обычный режим.
     */
    val portHideRoot: Flow<Boolean> = dataStore.data.map { prefs -> prefs[PORT_HIDE_ROOT] ?: false }

    /** Приложения, которым закрыт localhost в режиме скрытия через root. */
    val portHidePackages: Flow<String> = dataStore.data.map { prefs -> prefs[PORT_HIDE_PACKAGES] ?: "" }

    /** Игровой режим: каждый поток закреплён за одним воркером, без «скачущего» пинга. */
    val gameModeEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(GAME_MODE_ENABLED, profile)] ?: false
    }

    /** Автовключение игрового режима, когда на экране игра из списка. */
    val gameModeAuto: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(GAME_MODE_AUTO, profile)] ?: true
    }

    /** Игры, выбранные пользователем в игровом режиме. */
    val gamePackages: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(GAME_PACKAGES, profile)] ?: ""
    }

    /**
     * Игры, которые ходят через туннель, хотя по умолчанию игра идёт напрямую.
     * Пусто у тех, кого пользователь не переопределял.
     */
    val gameTunnelPackages: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(GAME_TUNNEL_PACKAGES, profile)] ?: ""
    }

    /** Дополнительные порты игр: пакеты на них идут игровым путём. */
    val gameExtraPorts: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(GAME_EXTRA_PORTS, profile)] ?: ""
    }

    /** Адреса своих серверов (кэш резолва): по ним трафик всегда идёт в туннель. */
    val ownServerIps: Flow<String> = dataStore.data.map { prefs ->
        prefs[OWN_SERVER_IPS] ?: ""
    }

    /** Режим сейчас активен (вручную или автоматически) — читает TunnelManager. */
    val gameAutoActive: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(GAME_AUTO_ACTIVE, profile)] ?: false
    }

    val domainIsWhitelist: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DOMAIN_IS_WHITELIST, profile)] ?: false
    }

    val directDomains: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DIRECT_DOMAINS, profile)] ?: ""
    }

    val directDomainsBlack: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DIRECT_DOMAINS_BLACK, profile)]
            ?: prefs[getProfileKey(DIRECT_DOMAINS, profile)]
            ?: ""
    }

    val directDomainsWhite: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DIRECT_DOMAINS_WHITE, profile)] ?: ""
    }

    val ipRoutingEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(IP_ROUTING_ENABLED, profile)] ?: false
    }

    val ipIsWhitelist: Flow<Boolean> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(IP_IS_WHITELIST, profile)] ?: false
    }

    val directIpsBlack: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DIRECT_IPS_BLACK, profile)] ?: ""
    }

    val directIpsWhite: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(DIRECT_IPS_WHITE, profile)] ?: ""
    }

    val profileNames: Flow<Map<Int, String>> = dataStore.data.map { prefs ->
        (MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX).associateWith { p ->
            val name = prefs[getProfileKey(PROFILE_NAME, p)]
            if (name.isNullOrBlank()) "Профиль $p" else name
        }
    }

    suspend fun saveProfileName(profile: Int, name: String) {
        dataStore.edit { prefs ->
            val trimmed = name.trim()
            if (trimmed.isEmpty() || trimmed == "Профиль $profile") {
                prefs.remove(getProfileKey(PROFILE_NAME, profile))
            } else {
                prefs[getProfileKey(PROFILE_NAME, profile)] = trimmed
            }
        }
    }

    val extraWorkers: Flow<Boolean> = kotlinx.coroutines.flow.flowOf(false)
    val autoJsRiskAcknowledged: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[AUTO_JS_RISK_ACKNOWLEDGED] ?: false
    }
    val tcpTransportRiskAcknowledged: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[TCP_TRANSPORT_RISK_ACKNOWLEDGED] ?: false
    }
    val maxTransportRiskAcknowledged: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[MAX_TRANSPORT_RISK_ACKNOWLEDGED] ?: false
    }
    val autoPauseOnWifi: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[AUTO_PAUSE_ON_WIFI] ?: false
    }
    val autoConnectOnLaunch: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[AUTO_CONNECT_ON_LAUNCH] ?: false
    }
    val batterySaverMode: Flow<String> = dataStore.data.map { it[BATTERY_SAVER_MODE] ?: BatterySaver.DEFAULT_MODE }
    val batterySaverPercent: Flow<Int> = dataStore.data.map { it[BATTERY_SAVER_PERCENT] ?: BatterySaver.DEFAULT_PERCENT }
    suspend fun isBatteryOptimizationPromptHandled(): Boolean =
        dataStore.data.first()[BATTERY_OPTIMIZATION_PROMPT_HANDLED] ?: false

    val themeMode: Flow<String> = dataStore.data.map { it[THEME_MODE] ?: "system" }
    val isDynamicColor: Flow<Boolean> = dataStore.data.map { it[IS_DYNAMIC_COLOR] ?: false }
    // "classic" — монохромный стиль по умолчанию; список стилей живёт в MrttStyles.
    val themePalette: Flow<String> = dataStore.data.map { it[THEME_PALETTE] ?: "classic" }

    val selectedFingerprint: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(SELECTED_FINGERPRINT, profile)] ?: "firefox"
    }
    val activeClientIds: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(ACTIVE_CLIENT_IDS, profile)] ?: MrttConstants.Tunnel.DEFAULT_CLIENT_IDS
    }
    val clientIdCheckResults: Flow<String> = dataStore.data.map { prefs ->
        prefs[CLIENT_ID_CHECK_RESULTS] ?: "{}"
    }
    val vkHashCheckResults: Flow<String> = dataStore.data.map { prefs ->
        val profile = prefs[ACTIVE_PROFILE] ?: 0
        prefs[getProfileKey(VK_HASH_CHECK_RESULTS, profile)] ?: "{}"
    }
    val connectionGeneration: Flow<Long> = dataStore.data.map { prefs ->
        prefs[CONNECTION_GENERATION] ?: 0L
    }

    val tunnelWasRunning: Flow<Boolean> = dataStore.data.map { it[TUNNEL_WAS_RUNNING] ?: false }
    val updateLastCheckAt: Flow<Long> = dataStore.data.map { it[UPDATE_LAST_CHECK_AT] ?: 0L }
    val updateLatestVersion: Flow<String> = dataStore.data.map { it[UPDATE_LATEST_VERSION] ?: "" }
    val updateLastError: Flow<String> = dataStore.data.map { it[UPDATE_LAST_ERROR] ?: "" }
    val updateCheckIntervalHours: Flow<Int> = dataStore.data.map { it[UPDATE_CHECK_INTERVAL_HOURS] ?: 24 }
    val updatePostponeUntil: Flow<Long> = dataStore.data.map { it[UPDATE_POSTPONE_UNTIL] ?: 0L }
    val updatePostponeVersion: Flow<String> = dataStore.data.map { it[UPDATE_POSTPONE_VERSION] ?: "" }

    // Last in the class, after every property: Kotlin assigns them top to bottom, and the collectors below start on
    // other threads at once. Above the flows they read, a collector could run before its flow was assigned and call
    // collect on null, which crashed the app at launch on slower phones (Redmi).
    init {
        if (migrationsStarted.compareAndSet(false, true)) {
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                migrateConnectionPasswordsToLocalStorage()
                migrateSecretsToKeystore()
                migrateLegacyWhitelistMode()
            }
        }
        if (uiCacheStarted.compareAndSet(false, true)) {
            CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
                launch {
                    dataStore.edit { prefs ->
                        for (p in MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX) {
                            prefs[getProfileKey(EXTRA_WORKERS, p)] = false
                        }
                    }
                }
                launch { vkHashMode.collect { cachedVkHashMode = it } }
                launch { vkSession.collect { cachedVkSession = it } }
                // Вход через приложение ВК: тот же кэш, чтобы проверка привязки
                // не ходила в DataStore на каждом запуске.
                launch { vkIdToken.collect { cachedVkIdToken = it } }
                launch { obfsMode.collect { cachedObfsMode = it } }
                launch { hideTunnelFingerprint.collect { cachedHideTunnelFingerprint = it } }
                launch { turnTransport.collect { cachedTurnTransport = it } }
                launch { srtpMode.collect { cachedSrtpMode = it } }
                launch { mrttLinkMode.collect { cachedMrttLinkMode = it } }
                launch { workersPerHash.collect { cachedWorkersPerHash = it } }
                launch { manualPortsEnabled.collect { cachedManualPortsEnabled = it } }
                launch { serverPeerPort.collect { cachedServerPeerPort = it } }
                cachedExtraWorkers = false
                launch { customTurnIps.collect { cachedCustomTurnIps = it } }
                launch { excludedApps.collect { cachedExcludedApps = it } }
                launch { whitelistApps.collect { cachedWhitelistApps = it } }
                launch { appDirectFiltered.collect { cachedAppDirectFiltered = it } }
                launch { appDirectRaw.collect { cachedAppDirectRaw = it } }
                launch { isWhitelist.collect { cachedIsWhitelist = it } }
                launch { domainRoutingEnabled.collect { cachedDomainRoutingEnabled = it } }
                launch { domainIsWhitelist.collect { cachedDomainIsWhitelist = it } }
                launch { excludeRuZonesEnabled.collect { cachedExcludeRuZonesEnabled = it } }
                launch { templateDomainsEnabled.collect { cachedTemplateDomainsEnabled = it } }
                launch { directDomains.collect { cachedDirectDomains = it } }
                launch { directDomainsBlack.collect { cachedDirectDomainsBlack = it } }
                launch { directDomainsWhite.collect { cachedDirectDomainsWhite = it } }
                launch { ipRoutingEnabled.collect { cachedIpRoutingEnabled = it } }
                launch { ipIsWhitelist.collect { cachedIpIsWhitelist = it } }
                launch { directIpsBlack.collect { cachedDirectIpsBlack = it } }
                launch { directIpsWhite.collect { cachedDirectIpsWhite = it } }
                launch { gameModeEnabled.collect { cachedGameModeEnabled = it } }
                launch { gameModeAuto.collect { cachedGameModeAuto = it } }
                launch { ownServerIps.collect { cachedOwnServerIps = it } }
                launch { mrttLink.collect { cachedLinkVkToken = linkVkTokenOf(it) } }
            }
        }
    }

    suspend fun saveTunnelWasRunning(running: Boolean) {
        dataStore.edit { prefs ->
            prefs[TUNNEL_WAS_RUNNING] = running
        }
    }

    suspend fun saveThemeMode(mode: String) {
        dataStore.edit { prefs ->
            prefs[THEME_MODE] = mode
        }
    }

    suspend fun saveDynamicColor(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[IS_DYNAMIC_COLOR] = enabled
        }
    }

    suspend fun saveThemePalette(palette: String) {
        dataStore.edit { prefs ->
            prefs[THEME_PALETTE] = palette
        }
    }

    suspend fun saveFingerprint(fingerprint: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(SELECTED_FINGERPRINT, profile)] = fingerprint
        }
    }

    suspend fun saveActiveClientIds(clientIds: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(ACTIVE_CLIENT_IDS, profile)] = clientIds
        }
    }

    suspend fun saveClientIdCheckResults(resultsJson: String) {
        dataStore.edit { prefs ->
            prefs[CLIENT_ID_CHECK_RESULTS] = resultsJson
        }
    }

    suspend fun saveVkHashCheckResults(resultsJson: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(VK_HASH_CHECK_RESULTS, profile)] = resultsJson
        }
    }

    suspend fun invalidateVkHash(hash: String) {
        val normalized = hash.trim()
        if (normalized.isEmpty()) return
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            val key = getProfileKey(VK_HASH_CHECK_RESULTS, profile)
            val results = VkHashValidationCodec.decode(prefs[key] ?: "{}") +
                (normalized to VkHashValidationStatus.Invalid)
            prefs[key] = VkHashValidationCodec.encode(results)
        }
    }

    suspend fun reserveConnectionGeneration(
        proposed: Long = 0L,
        nowSeconds: Long = System.currentTimeMillis() / 1000L,
    ): Long {
        var reserved = 0L
        dataStore.edit { prefs ->
            reserved = reserveTunnelGenerationId(
                nowSeconds.coerceAtLeast(0L),
                proposed.coerceAtLeast(0L),
                prefs[CONNECTION_GENERATION] ?: 0L,
            )
            prefs[CONNECTION_GENERATION] = reserved
        }
        return reserved
    }

    suspend fun recordConnectionGeneration(generation: Long): Long {
        var persisted = 0L
        dataStore.edit { prefs ->
            persisted = maxOf(prefs[CONNECTION_GENERATION] ?: 0L, generation.coerceAtLeast(0L))
            prefs[CONNECTION_GENERATION] = persisted
        }
        return persisted
    }

    suspend fun saveTunnelDiagnostic(code: String, message: String) {
        val normalizedCode = code.trim().take(80)
        val normalizedMessage = message.trim().replace(Regex("\\s+"), " ").take(400)
        dataStore.edit { prefs ->
            prefs[TUNNEL_LAST_DIAGNOSTIC] = "$normalizedCode|$normalizedMessage"
            prefs[TUNNEL_LAST_DIAGNOSTIC_AT] = System.currentTimeMillis()
        }
    }

    suspend fun clearTunnelDiagnostic() {
        dataStore.edit { prefs ->
            prefs.remove(TUNNEL_LAST_DIAGNOSTIC)
            prefs.remove(TUNNEL_LAST_DIAGNOSTIC_AT)
        }
    }

    suspend fun saveUpdateState(lastCheckAt: Long, latestVersion: String, error: String) {
        dataStore.edit { prefs ->
            prefs[UPDATE_LAST_CHECK_AT] = lastCheckAt
            prefs[UPDATE_LATEST_VERSION] = latestVersion
            prefs[UPDATE_LAST_ERROR] = error
        }
    }

    suspend fun saveUpdateCheckIntervalHours(hours: Int) {
        dataStore.edit { prefs ->
            prefs[UPDATE_CHECK_INTERVAL_HOURS] = hours
        }
    }

    suspend fun saveUpdatePostpone(version: String, until: Long) {
        dataStore.edit { prefs ->
            prefs[UPDATE_POSTPONE_VERSION] = version
            prefs[UPDATE_POSTPONE_UNTIL] = until
        }
    }

    suspend fun saveUpdateDialogShown(version: String, shownAt: Long) {
        dataStore.edit { prefs ->
            prefs[UPDATE_DIALOG_LAST_SHOWN_VERSION] = version
            prefs[UPDATE_DIALOG_LAST_SHOWN_AT] = shownAt
        }
    }

    suspend fun saveUpdateDialogAction(version: String, action: String, actedAt: Long) {
        dataStore.edit { prefs ->
            prefs[UPDATE_DIALOG_LAST_ACTION_VERSION] = version
            prefs[UPDATE_DIALOG_LAST_ACTION] = action
            prefs[UPDATE_DIALOG_LAST_ACTION_AT] = actedAt
        }
    }

    suspend fun saveActiveProfile(profile: Int) {
        dataStore.edit { prefs ->
            prefs[ACTIVE_PROFILE] = profile.coerceIn(
                MrttConstants.Profiles.MIN_INDEX,
                MrttConstants.Profiles.MAX_INDEX,
            )
        }
    }

    suspend fun saveShowSystemApps(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[SHOW_SYSTEM_APPS] = enabled
        }
    }

    suspend fun saveLoggingEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[LOGGING_ENABLED] = enabled
        }
    }

    suspend fun saveHideTunnelFingerprint(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[HIDE_TUNNEL_FINGERPRINT] = enabled
            if (enabled) {
                cachedHideTunnelFingerprint = true
            }
        }
    }

    suspend fun saveInfoActionsExpanded(expanded: Boolean) {
        dataStore.edit { prefs ->
            prefs[INFO_ACTIONS_EXPANDED] = expanded
        }
    }

    suspend fun saveInfoProjectExpanded(expanded: Boolean) {
        dataStore.edit { prefs ->
            prefs[INFO_PROJECT_EXPANDED] = expanded
        }
    }

    suspend fun saveMrttLink(link: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(MRTT_LINK, profile)] = link
        }
    }

    suspend fun saveMrttParticipantLink(link: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(MRTT_LINK, profile)] = link
            prefs[getProfileKey(MRTT_LINK_MODE, profile)] = true
        }
    }

    suspend fun saveVpsServersJson(json: String) {
        dataStore.edit { it[VPS_SERVERS] = json }
    }

    suspend fun vpsServersMigrated(): Boolean = dataStore.data.first()[VPS_SERVERS_MIGRATED] == true

    suspend fun markVpsServersMigrated() {
        dataStore.edit { it[VPS_SERVERS_MIGRATED] = true }
    }

    suspend fun saveConnectionProfilesJson(json: String) {
        dataStore.edit { it[CONNECTION_PROFILES] = json }
    }

    /** Активный профиль удалён: подключаться больше не к чему, его ссылка не должна остаться. */
    suspend fun clearActiveConnectionProfile() {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs.remove(ACTIVE_CONNECTION_PROFILE)
            prefs.remove(getProfileKey(MRTT_LINK, profile))
        }
    }

    /** Делает профиль активным: его ссылка становится ссылкой подключения. */
    suspend fun activateConnectionProfile(id: String, link: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[ACTIVE_CONNECTION_PROFILE] = id
            prefs[getProfileKey(MRTT_LINK, profile)] = link
            prefs[getProfileKey(MRTT_LINK_MODE, profile)] = true
        }
    }

    suspend fun connectionProfilesMigrated(): Boolean =
        dataStore.data.first()[CONNECTION_PROFILES_MIGRATED] == true

    suspend fun markConnectionProfilesMigrated() {
        dataStore.edit { it[CONNECTION_PROFILES_MIGRATED] = true }
    }

    /** Старые слоты профилей, где был настроен деплой. */
    internal suspend fun legacyDeployServers(): List<DeploySettingsSnapshot> = withContext(Dispatchers.IO) {
        val prefs = dataStore.data.first()
        (MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX)
            .map { readDeploySnapshot(prefs, it) }
            .filter { it.ip.isNotBlank() }
    }

    /** Ссылки старых слотов: ссылка участника или собранная из настроек владельца. */
    internal suspend fun legacyConnectionLinks(): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        val prefs = dataStore.data.first()
        (MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX).mapNotNull { profile ->
            val name = prefs[getProfileKey(PROFILE_NAME, profile)] ?: "Профиль $profile"
            val link = prefs[getProfileKey(MRTT_LINK, profile)].orEmpty().trim()
            if (prefs[getProfileKey(MRTT_LINK_MODE, profile)] == true) {
                return@mapNotNull link.takeIf { it.isNotEmpty() }?.let { name to it }
            }
            val peer = prefs[getProfileKey(PEER, profile)].orEmpty().trim()
            val password = readConnectionPasswordState(prefs, profile).value
            if (peer.isEmpty() || password.isEmpty()) return@mapNotNull null
            val host = peer.substringBeforeLast(':').takeIf { peer.count { it == ':' } == 1 } ?: peer
            val port = peer.substringAfterLast(':', "").toIntOrNull()
                ?: if (prefs[getProfileKey(MANUAL_PORTS_ENABLED, profile)] == true) {
                    prefs[getProfileKey(SERVER_PEER_PORT, profile)] ?: MrttConstants.Network.DEFAULT_SERVER_PEER_PORT
                } else {
                    MrttConstants.Network.DEFAULT_SERVER_PEER_PORT
                }
            val hashes = prefs[getProfileKey(VK_HASHES, profile)].orEmpty()
                .split(Regex("[,\\s]+")).map(String::trim).filter { it.length >= 16 }.distinct().take(6)
            runCatching {
                name to com.mrtt.client.ui.utils.formatMrttLink(host, port, password, hashes)
            }.getOrNull()
        }
    }

    suspend fun saveWorkersPerHash(workersPerHash: Int) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(WORKERS_PER_HASH, profile)] = WorkerCountPolicy.normalize(workersPerHash, maximum = MrttConstants.Tunnel.MAX_WORKERS)
        }
    }

    suspend fun saveParticipantTunnelSettings(vkHashes: String, workersPerHash: Int) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(VK_HASHES, profile)] = vkHashes
            prefs[getProfileKey(WORKERS_PER_HASH, profile)] =
                WorkerCountPolicy.normalize(workersPerHash, maximum = MrttConstants.Tunnel.MAX_WORKERS)
        }
    }

    suspend fun save(
        peer: String,
        vkHashes: String,
        secondaryVkHash: String,
        workersPerHash: Int,
        protocol: String,
        listenPort: Int,
        sni: String = "",
        noDns: Boolean = false
    ) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(PEER, profile)] = peer
            prefs[getProfileKey(VK_HASHES, profile)] = vkHashes
            prefs[getProfileKey(SECONDARY_VK_HASH, profile)] = secondaryVkHash
            prefs[getProfileKey(WORKERS_PER_HASH, profile)] = WorkerCountPolicy.normalize(workersPerHash, maximum = MrttConstants.Tunnel.MAX_WORKERS)
            prefs[getProfileKey(PROTOCOL, profile)] = protocol
            prefs[getProfileKey(LISTEN_PORT, profile)] = listenPort
            prefs[getProfileKey(SNI, profile)] = sni
            prefs[getProfileKey(NO_DNS, profile)] = noDns
        }
    }

    suspend fun saveTransportMode(mode: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(TRANSPORT_MODE, profile)] =
                when (mode) {
                    MrttConstants.Transport.MODE_MAX, MrttConstants.Transport.MODE_JITSI -> mode
                    else -> MrttConstants.Transport.MODE_VK
                }
        }
    }

    suspend fun saveTunnelMtu(mtu: Int) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(TUNNEL_MTU, profile)] =
                mtu.coerceIn(MrttConstants.Vpn.MTU_MIN, MrttConstants.Vpn.MTU_MAX)
        }
    }

    suspend fun saveManualPortsEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(MANUAL_PORTS_ENABLED, profile)] = enabled
            if (!enabled) {
                prefs[getProfileKey(DEPLOY_SSH_PORT, profile)] = MrttConstants.Network.DEFAULT_SSH_PORT.toString()
                prefs[getProfileKey(SERVER_PEER_PORT, profile)] = MrttConstants.Network.DEFAULT_SERVER_PEER_PORT
                prefs[getProfileKey(SERVER_WEB_PORT, profile)] = MrttConstants.Network.DEFAULT_SERVER_WEB_PORT
            }
        }
    }

    suspend fun saveSshKeysMode(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(SSH_KEYS_MODE, profile)] = enabled
        }
    }

    suspend fun saveDockerInstall(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(DOCKER_INSTALL, profile)] = enabled
        }
    }

    suspend fun saveDeploySecretPath(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            val keyEnabled = getProfileKey(DEPLOY_SECRET_PATH_ENABLED, profile)
            val keyUuid = getProfileKey(DEPLOY_SECRET_PATH_UUID, profile)
            prefs[keyEnabled] = enabled
            if (enabled && prefs[keyUuid].isNullOrBlank()) {
                prefs[keyUuid] = UUID.randomUUID().toString()
            }
        }
    }

    suspend fun regenerateDeploySecretPathUuid(): String {
        val newUuid = UUID.randomUUID().toString()
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(DEPLOY_SECRET_PATH_UUID, profile)] = newUuid
        }
        return newUuid
    }

    suspend fun saveSshKeys(privateKey: String, keyPassphrase: String, certificate: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs.putSecret(SSH_PRIVATE_KEY_ENCRYPTED, SSH_PRIVATE_KEY, privateKey, profile)
            prefs.putSecret(SSH_KEY_PASSPHRASE_ENCRYPTED, SSH_KEY_PASSPHRASE, keyPassphrase, profile)
            prefs.putSecret(SSH_CERTIFICATE_ENCRYPTED, SSH_CERTIFICATE, certificate, profile)
        }
    }

    suspend fun savePorts(peer: Int, web: Int, sshPortStr: String) {
        val profile = activeProfile.first()
        dataStore.edit { prefs ->
            prefs[getProfileKey(SERVER_PEER_PORT, profile)] = peer
            prefs[getProfileKey(SERVER_WEB_PORT, profile)] = web
            prefs[getProfileKey(DEPLOY_SSH_PORT, profile)] = sshPortStr
        }
    }

    suspend fun saveServerPeerPort(peer: Int) {
        if (peer !in 1..65535) return
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(SERVER_PEER_PORT, profile)] = peer
        }
    }

    suspend fun saveDeploy(ip: String) {
        val profile = activeProfile.first()
        dataStore.edit { prefs ->
            prefs[getProfileKey(DEPLOY_IP, profile)] = ip
        }
    }

    suspend fun saveExcludedApps(packages: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(EXCLUDED_APPS, profile)] = packages
            prefs[SPLIT_TUNNEL_WHITELIST_MIGRATED] = true
        }
    }

    suspend fun saveWhitelistApps(packages: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(WHITELIST_APPS, profile)] = packages
            prefs[SPLIT_TUNNEL_WHITELIST_MIGRATED] = true
        }
    }

    suspend fun saveAppDirectLists(filtered: String, raw: String) = editAppRouting(
        AppRoutingPatch(directFiltered = filtered, directRaw = raw),
    )

    /**
     * Одна запись DataStore на все изменения маршрутизации приложений: частичные
     * записи из UI гонялись между собой, и последняя могла вернуть старые списки.
     */
    suspend fun editAppRouting(patch: AppRoutingPatch) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            patch.excluded?.let { prefs[getProfileKey(EXCLUDED_APPS, profile)] = it }
            patch.whitelist?.let { prefs[getProfileKey(WHITELIST_APPS, profile)] = it }
            patch.isWhitelist?.let { prefs[getProfileKey(IS_WHITELIST, profile)] = it }
            patch.directFiltered?.let { prefs[getProfileKey(APP_DIRECT_FILTERED, profile)] = it }
            patch.directRaw?.let { prefs[getProfileKey(APP_DIRECT_RAW, profile)] = it }
            prefs[SPLIT_TUNNEL_WHITELIST_MIGRATED] = true
        }
    }

    suspend fun saveAppRoutingLists(blacklist: String, whitelist: String, isWhitelist: Boolean? = null) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(EXCLUDED_APPS, profile)] = blacklist
            prefs[getProfileKey(WHITELIST_APPS, profile)] = whitelist
            if (isWhitelist != null) prefs[getProfileKey(IS_WHITELIST, profile)] = isWhitelist
            prefs[SPLIT_TUNNEL_WHITELIST_MIGRATED] = true
        }
    }

    suspend fun saveConnectionPassword(password: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            val localKey = getProfileKey(CONNECTION_PASSWORD_LOCAL, profile)
            val legacyKey = getProfileKey(CONNECTION_PASSWORD, profile)
            val encryptedKey = getProfileKey(CONNECTION_PASSWORD_ENCRYPTED, profile)
            if (password.isBlank()) {
                prefs.remove(localKey)
            } else {
                prefs[localKey] = password
            }
            prefs.remove(legacyKey)
            prefs.remove(encryptedKey)
        }
    }

    suspend fun resetUnreadableConnectionPassword(): Boolean {
        var reset = false
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            val localKey = getProfileKey(CONNECTION_PASSWORD_LOCAL, profile)
            val legacyKey = getProfileKey(CONNECTION_PASSWORD, profile)
            val encryptedKey = getProfileKey(CONNECTION_PASSWORD_ENCRYPTED, profile)
            if (
                shouldResetUnreadableTunnelPassword(
                    prefs[localKey],
                    prefs[legacyKey],
                    prefs[encryptedKey],
                    secureStore::decrypt,
                )
            ) {
                prefs.remove(localKey)
                prefs.remove(legacyKey)
                prefs.remove(encryptedKey)
                reset = true
            }
        }
        return reset
    }

    suspend fun saveDeploySecrets(mainPass: String, sshLogin: String, sshPass: String, webLogin: String, webPass: String) {
        val profile = activeProfile.first()
        dataStore.edit { prefs ->
            prefs.putSecret(DEPLOY_MAIN_PASSWORD_ENCRYPTED, DEPLOY_MAIN_PASSWORD, mainPass, profile)
            prefs[getProfileKey(DEPLOY_LOGIN, profile)] = sshLogin
            prefs.putSecret(DEPLOY_PASSWORD_ENCRYPTED, DEPLOY_PASSWORD, sshPass, profile)
            prefs[getProfileKey(DEPLOY_WEB_LOGIN, profile)] = webLogin
            prefs.putSecret(DEPLOY_WEB_PASSWORD_ENCRYPTED, DEPLOY_WEB_PASSWORD, webPass, profile)
        }
    }

    suspend fun saveVkAuthMode(mode: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            val normalized = when (mode) {
                MrttConstants.VkAuth.MODE_CAPTCHA -> MrttConstants.VkAuth.MODE_CAPTCHA
                MrttConstants.VkAuth.MODE_AUTO_JS -> MrttConstants.VkAuth.MODE_AUTO_JS
                else -> MrttConstants.VkAuth.MODE_CALLS
            }
            prefs[getProfileKey(VK_AUTH_MODE, profile)] = normalized
            prefs[getProfileKey(VK_HASH_MODE, profile)] = vkHashModeForAuthMode(
                requestedAuthMode = normalized,
                currentHashMode = prefs[getProfileKey(VK_HASH_MODE, profile)],
                hasVkToken = readVkSession(prefs, profile).isNotBlank(),
            )
        }
    }

    suspend fun saveObfsMode(mode: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(OBFS_MODE, profile)] = mode
        }
    }

    suspend fun saveTurnTransport(transport: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(TURN_TRANSPORT, profile)] = when (transport) {
                MrttConstants.Tunnel.TURN_TRANSPORT_TCP_TLS -> MrttConstants.Tunnel.TURN_TRANSPORT_TCP_TLS
                else -> MrttConstants.Tunnel.DEFAULT_TURN_TRANSPORT
            }
        }
    }

    suspend fun saveSrtpMode(mode: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(SRTP_MODE, profile)] = when (mode) {
                MrttConstants.SrtpMode.WRAP -> MrttConstants.SrtpMode.WRAP
                MrttConstants.SrtpMode.DTLS -> MrttConstants.SrtpMode.DTLS
                else -> MrttConstants.SrtpMode.DEFAULT
            }
        }
    }

    suspend fun saveSelectedTurnSubnet(subnetId: String, ipLimit: String? = null) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            val limit = ipLimit ?: prefs[getProfileKey(TURN_SUBNET_IP_LIMIT, profile)] ?: "ALL"
            val allIps = if (subnetId.isNotBlank()) TurnSubnetRegistry.getIpsForSubnet(subnetId) else emptyList()
            val limitCount = limit.toIntOrNull()
            val ips = if (allIps.isEmpty()) {
                ""
            } else if (limitCount != null && limitCount > 0) {
                allIps.take(limitCount).joinToString(",")
            } else {
                allIps.joinToString(",")
            }
            prefs[getProfileKey(SELECTED_TURN_SUBNET, profile)] = subnetId
            prefs[getProfileKey(CUSTOM_TURN_IPS, profile)] = ips
            if (ipLimit != null) {
                prefs[getProfileKey(TURN_SUBNET_IP_LIMIT, profile)] = ipLimit
            }
        }
    }

    suspend fun saveTurnSubnetIpLimit(limit: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            val subnetId = prefs[getProfileKey(SELECTED_TURN_SUBNET, profile)] ?: ""
            val allIps = if (subnetId.isNotBlank()) TurnSubnetRegistry.getIpsForSubnet(subnetId) else emptyList()
            val limitCount = limit.toIntOrNull()
            val ips = if (allIps.isEmpty()) {
                ""
            } else if (limitCount != null && limitCount > 0) {
                allIps.take(limitCount).joinToString(",")
            } else {
                allIps.joinToString(",")
            }
            prefs[getProfileKey(TURN_SUBNET_IP_LIMIT, profile)] = limit
            prefs[getProfileKey(CUSTOM_TURN_IPS, profile)] = ips
        }
    }

    suspend fun saveExtraWorkers(enabled: Boolean = false) {
        dataStore.edit { prefs ->
            for (p in MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX) {
                prefs[getProfileKey(EXTRA_WORKERS, p)] = false
            }
        }
    }

    suspend fun saveAutoJsRiskAcknowledged(acknowledged: Boolean) {
        dataStore.edit { prefs ->
            prefs[AUTO_JS_RISK_ACKNOWLEDGED] = acknowledged
        }
    }

    suspend fun saveTcpTransportRiskAcknowledged(acknowledged: Boolean) {
        dataStore.edit { prefs ->
            prefs[TCP_TRANSPORT_RISK_ACKNOWLEDGED] = acknowledged
        }
    }

    suspend fun saveMaxTransportRiskAcknowledged(acknowledged: Boolean) {
        dataStore.edit { prefs ->
            prefs[MAX_TRANSPORT_RISK_ACKNOWLEDGED] = acknowledged
        }
    }

    suspend fun saveAutoPauseOnWifi(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[AUTO_PAUSE_ON_WIFI] = enabled
        }
    }

    suspend fun saveAutoConnectOnLaunch(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[AUTO_CONNECT_ON_LAUNCH] = enabled }
    }

    suspend fun saveBatterySaverMode(mode: String) {
        dataStore.edit { prefs -> prefs[BATTERY_SAVER_MODE] = mode }
    }

    suspend fun saveBatterySaverPercent(percent: Int) {
        dataStore.edit { prefs -> prefs[BATTERY_SAVER_PERCENT] = percent.coerceIn(5, 95) }
    }

    suspend fun markBatteryOptimizationPromptHandled() {
        dataStore.edit { prefs ->
            prefs[BATTERY_OPTIMIZATION_PROMPT_HANDLED] = true
        }
    }

    suspend fun saveCaptchaMode(mode: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(CAPTCHA_MODE, profile)] = mode
        }
    }

    suspend fun saveCaptchaSolveMethod(method: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(CAPTCHA_SOLVE_METHOD, profile)] = method
        }
    }

    suspend fun saveWbvCaptchaSolveMethod(method: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(CAPTCHA_WBV_SOLVE_METHOD, profile)] = method
            if (prefs[getProfileKey(CAPTCHA_MODE, profile)] == "wv") {
                prefs[getProfileKey(CAPTCHA_SOLVE_METHOD, profile)] = method
            }
        }
    }

    suspend fun saveVkHashMode(mode: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            val currentAuthMode = prefs[getProfileKey(VK_AUTH_MODE, profile)]
            val nextAuthMode = vkAuthModeForHashMode(mode, currentAuthMode)
            val selection = normalizeVkModeSelection(
                requestedAuthMode = nextAuthMode,
                requestedHashMode = mode,
                hasVkToken = readVkSession(prefs, profile).isNotBlank(),
            )
            prefs[getProfileKey(VK_AUTH_MODE, profile)] = selection.authMode
            prefs[getProfileKey(VK_HASH_MODE, profile)] = selection.hashMode
        }
    }

    /**
     * Вход через приложение ВК (VK ID) закончился токеном, а не куками.
     *
     * Куки приложения ВК нам недоступны, поэтому привязкой становится сам токен:
     * `access_token` живёт около часа, `refresh_token` — долго, и по нему токен
     * обновляется без повторного входа.
     */
    suspend fun saveVkIdTokens(accessToken: String, refreshToken: String, userId: String) {
        require(accessToken.isNotBlank())
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(VK_ACCESS_TOKEN_ENCRYPTED, profile)] =
                secureStore.encrypt(VK_ID_TOKEN_PREFIX + accessToken)
            prefs.putSecret(VK_ID_REFRESH_TOKEN_ENCRYPTED, VK_ID_REFRESH_TOKEN, refreshToken, profile)
            prefs[getProfileKey(VK_ACCESS_TOKEN_USER_ID, profile)] = userId
        }
    }

    private fun readVkIdToken(prefs: Preferences, profile: Int): String =
        readSecret(prefs, VK_ACCESS_TOKEN_ENCRYPTED, VK_ACCESS_TOKEN, profile)
            .takeIf { it.startsWith(VK_ID_TOKEN_PREFIX) }
            ?.removePrefix(VK_ID_TOKEN_PREFIX)
            .orEmpty()

    /**
     * Привязка VK есть в любом виде: куки веб-сессии или токен входа через
     * приложение ВК. Раньше проверялись только куки, поэтому вход через
     * приложение считался «не привязан», и туннель шёл за токеном впустую.
     */
    suspend fun hasAnyVkBinding(): Boolean = vkSession.first().isNotBlank() || vkIdToken.first().isNotBlank()

    suspend fun saveVkSession(cookies: String, userId: String) {
        require(cookies.isNotBlank())
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs.putSecret(VK_ACCESS_TOKEN_ENCRYPTED, VK_ACCESS_TOKEN, VK_SESSION_PREFIX + cookies, profile)
            prefs[getProfileKey(VK_ACCESS_TOKEN_USER_ID, profile)] = userId
        }
    }

    // Старые версии хранили здесь вечный токен API: он не считается привязкой, нужен вход заново.
    private fun readVkSession(prefs: Preferences, profile: Int): String =
        readSecret(prefs, VK_ACCESS_TOKEN_ENCRYPTED, VK_ACCESS_TOKEN, profile)
            .takeIf { it.startsWith(VK_SESSION_PREFIX) }
            ?.removePrefix(VK_SESSION_PREFIX)
            .orEmpty()

    suspend fun clearVkSession() {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs.remove(getProfileKey(VK_ACCESS_TOKEN_ENCRYPTED, profile))
            prefs.remove(getProfileKey(VK_ACCESS_TOKEN, profile))
            prefs.remove(getProfileKey(VK_ACCESS_TOKEN_USER_ID, profile))
            prefs.remove(getProfileKey(VK_ID_REFRESH_TOKEN_ENCRYPTED, profile))
            prefs.remove(getProfileKey(VK_ID_REFRESH_TOKEN, profile))
        }
    }

    suspend fun saveMaxBinding(
        token: String,
        groupId: String,
        expectedProfile: Int,
        deviceId: String = "",
    ) = withContext(Dispatchers.IO) {
        require(token.length >= 32 && token.none(Char::isWhitespace))
        require(com.mrtt.client.ui.utils.isValidMaxGroupId(groupId))
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            check(profile == expectedProfile) { "Профиль изменился во время привязки MAX" }
            prefs.putSecret(MAX_ACCESS_TOKEN_ENCRYPTED, MAX_ACCESS_TOKEN, token, profile)
            prefs[getProfileKey(MAX_GROUP_ID, profile)] = groupId
            val normalized = deviceId.trim()
            if (normalized.isNotEmpty() && normalized.length <= 64 && normalized.none(Char::isWhitespace)) {
                prefs[getProfileKey(MAX_DEVICE_ID, profile)] = normalized
            } else {
                // Без deviceId сессию не открыть: старый (чужой) не оставляем.
                prefs.remove(getProfileKey(MAX_DEVICE_ID, profile))
            }
        }
    }

    /**
     * Сохранить новый токен сессии MAX.
     *
     * Сервер обменивает токен при первом входе: старый после этого
     * недействителен (`login.cred`, «Access token is broken»), поэтому
     * присланный сервером токен обязан попасть в профиль.
     */
    suspend fun saveMaxAccessToken(token: String) = withContext(Dispatchers.IO) {
        require(token.length >= 32 && token.none(Char::isWhitespace))
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs.putSecret(MAX_ACCESS_TOKEN_ENCRYPTED, MAX_ACCESS_TOKEN, token, profile)
        }
    }

    suspend fun saveIsWhitelist(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(IS_WHITELIST, profile)] = enabled
            prefs[SPLIT_TUNNEL_WHITELIST_MIGRATED] = true
        }
    }

    suspend fun saveExceptionsMode(packages: String, isWhitelist: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            if (isWhitelist) {
                prefs[getProfileKey(WHITELIST_APPS, profile)] = packages
            } else {
                prefs[getProfileKey(EXCLUDED_APPS, profile)] = packages
            }
            prefs[getProfileKey(IS_WHITELIST, profile)] = isWhitelist
            prefs[SPLIT_TUNNEL_WHITELIST_MIGRATED] = true
        }
    }

    suspend fun saveDomainRoutingEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(DOMAIN_ROUTING_ENABLED, profile)] = enabled
        }
    }

    suspend fun saveExcludeRuZonesEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(EXCLUDE_RU_ZONES_ENABLED, profile)] = enabled
        }
    }

    suspend fun saveTemplateDomainsEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(TEMPLATE_DOMAINS_ENABLED, profile)] = enabled
        }
    }

    suspend fun saveAdblockEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(ADBLOCK_ENABLED, profile)] = enabled
        }
    }

    suspend fun saveAdblockDomains(text: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(ADBLOCK_DOMAINS, profile)] = text
        }
    }

    suspend fun saveAdblockSubscriptions(json: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(ADBLOCK_SUBSCRIPTIONS, profile)] = json
        }
    }

    suspend fun saveAdblockCategories(categories: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(ADBLOCK_CATEGORIES, profile)] = categories
        }
    }

    suspend fun savePortHideRoot(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[PORT_HIDE_ROOT] = enabled }
    }

    suspend fun savePortHidePackages(packages: String) {
        dataStore.edit { prefs -> prefs[PORT_HIDE_PACKAGES] = packages }
    }

    suspend fun saveGeositeRuEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(GEOSITE_RU_ENABLED, profile)] = enabled
        }
    }

    suspend fun saveGameModeEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(GAME_MODE_ENABLED, profile)] = enabled
        }
    }

    suspend fun saveGameModeAuto(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(GAME_MODE_AUTO, profile)] = enabled
        }
    }

    suspend fun saveGamePackages(packages: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(GAME_PACKAGES, profile)] = packages
        }
    }

    suspend fun saveGameTunnelPackages(packages: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(GAME_TUNNEL_PACKAGES, profile)] = packages
        }
    }

    suspend fun saveGameExtraPorts(ports: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(GAME_EXTRA_PORTS, profile)] = ports
        }
    }

    suspend fun saveOwnServerIps(ips: String) {
        dataStore.edit { prefs -> prefs[OWN_SERVER_IPS] = ips }
    }

    suspend fun saveGameAutoActive(active: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(GAME_AUTO_ACTIVE, profile)] = active
        }
    }

    suspend fun saveDomainIsWhitelist(isWhitelist: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(DOMAIN_IS_WHITELIST, profile)] = isWhitelist
        }
    }

    suspend fun saveDirectDomains(domains: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(DIRECT_DOMAINS, profile)] = domains
            prefs[getProfileKey(DIRECT_DOMAINS_BLACK, profile)] = domains
        }
    }

    suspend fun saveDirectDomainsBlack(domains: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(DIRECT_DOMAINS_BLACK, profile)] = domains
            prefs[getProfileKey(DIRECT_DOMAINS, profile)] = domains
        }
    }

    suspend fun saveDirectDomainsWhite(domains: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(DIRECT_DOMAINS_WHITE, profile)] = domains
        }
    }

    suspend fun saveIpRoutingEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(IP_ROUTING_ENABLED, profile)] = enabled
        }
    }

    suspend fun saveIpIsWhitelist(isWhitelist: Boolean) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(IP_IS_WHITELIST, profile)] = isWhitelist
        }
    }

    suspend fun saveDirectIpsBlack(ips: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(DIRECT_IPS_BLACK, profile)] = ips
        }
    }

    suspend fun saveDirectIpsWhite(ips: String) {
        dataStore.edit { prefs ->
            val profile = prefs[ACTIVE_PROFILE] ?: 0
            prefs[getProfileKey(DIRECT_IPS_WHITE, profile)] = ips
        }
    }

    private suspend fun migrateSecretsToKeystore() {
        dataStore.edit { prefs ->
            for (profile in MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX) {
                prefs.migrateSecret(getProfileKey(DEPLOY_PASSWORD_ENCRYPTED, profile), getProfileKey(DEPLOY_PASSWORD, profile))
                prefs.migrateSecret(getProfileKey(DEPLOY_MAIN_PASSWORD_ENCRYPTED, profile), getProfileKey(DEPLOY_MAIN_PASSWORD, profile))
                prefs.migrateSecret(getProfileKey(DEPLOY_WEB_PASSWORD_ENCRYPTED, profile), getProfileKey(DEPLOY_WEB_PASSWORD, profile))
            }
        }
    }

    private suspend fun migrateConnectionPasswordsToLocalStorage() {
        dataStore.edit { prefs ->
            for (profile in MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX) {
                val localKey = getProfileKey(CONNECTION_PASSWORD_LOCAL, profile)
                val legacyKey = getProfileKey(CONNECTION_PASSWORD, profile)
                val encryptedKey = getProfileKey(CONNECTION_PASSWORD_ENCRYPTED, profile)
                val password = resolveTunnelPasswordStorage(
                    prefs[localKey],
                    prefs[legacyKey],
                    prefs[encryptedKey],
                    secureStore::decrypt,
                )
                if (password.state == StoredSecretState.Readable) {
                    if (password.value.isBlank()) {
                        prefs.remove(localKey)
                    } else {
                        prefs[localKey] = password.value
                    }
                    prefs.remove(legacyKey)
                    prefs.remove(encryptedKey)
                }
            }
        }
    }

    suspend fun migrateLegacyWhitelistMode() {
        val currentPrefs = dataStore.data.first()
        if (currentPrefs[SPLIT_TUNNEL_WHITELIST_MIGRATED] == true) return

        val hasLegacyWhitelist =
            (MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX).any { profile ->
            currentPrefs[getProfileKey(IS_WHITELIST, profile)] == true
        }
        val installedApps = if (hasLegacyWhitelist) installedSplitTunnelPackages() else emptySet()
        dataStore.edit { prefs ->
            if (prefs[SPLIT_TUNNEL_WHITELIST_MIGRATED] == true) return@edit

            for (profile in MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX) {
                val whitelistKey = getProfileKey(IS_WHITELIST, profile)
                val appsKey = getProfileKey(EXCLUDED_APPS, profile)
                val whitelistAppsKey = getProfileKey(WHITELIST_APPS, profile)
                if (prefs[whitelistAppsKey] == null && prefs[whitelistKey] == true) {
                    val existing = prefs[appsKey]
                    if (!existing.isNullOrEmpty()) {
                        prefs[whitelistAppsKey] = existing
                    }
                }
                if (prefs[whitelistKey] == true) {
                    val legacyExcluded = prefs[appsKey]
                        ?.split(",")
                        ?.filter { it.isNotEmpty() }
                        ?.toSet()
                        ?: emptySet()
                    prefs[appsKey] = (installedApps - legacyExcluded).sorted().joinToString(",")
                }
            }

            prefs[SPLIT_TUNNEL_WHITELIST_MIGRATED] = true
        }
    }

    private fun installedSplitTunnelPackages(): Set<String> {
        return runCatching {
            appContext.packageManager
                .getInstalledApplications(PackageManager.GET_META_DATA)
                .map { it.packageName }
                .filter {
                    it != appContext.packageName &&
                        !it.contains("vkontakte") &&
                        !it.contains("vk.calls")
                }
                .toSet()
        }.getOrDefault(emptySet())
    }

    private fun readSecret(
        prefs: Preferences,
        encryptedKey: Preferences.Key<String>,
        legacyKey: Preferences.Key<String>,
        profile: Int
    ): String = readSecretState(prefs, encryptedKey, legacyKey, profile).value

    private fun readSecretState(
        prefs: Preferences,
        encryptedKey: Preferences.Key<String>,
        legacyKey: Preferences.Key<String>,
        profile: Int
    ): StoredSecret {
        val profEncryptedKey = getProfileKey(encryptedKey, profile)
        val profLegacyKey = getProfileKey(legacyKey, profile)
        return resolveStoredSecret(
            prefs[profEncryptedKey],
            prefs[profLegacyKey],
            secureStore::decrypt,
        )
    }

    private fun readConnectionPasswordState(
        prefs: Preferences,
        profile: Int,
    ): StoredSecret = resolveTunnelPasswordStorage(
        prefs[getProfileKey(CONNECTION_PASSWORD_LOCAL, profile)],
        prefs[getProfileKey(CONNECTION_PASSWORD, profile)],
        prefs[getProfileKey(CONNECTION_PASSWORD_ENCRYPTED, profile)],
        secureStore::decrypt,
    )

    private fun MutablePreferences.putSecret(
        encryptedKey: Preferences.Key<String>,
        legacyKey: Preferences.Key<String>,
        value: String,
        profile: Int
    ) {
        val profEncryptedKey = getProfileKey(encryptedKey, profile)
        val profLegacyKey = getProfileKey(legacyKey, profile)
        if (value.isBlank()) {
            remove(profEncryptedKey)
            remove(profLegacyKey)
        } else {
            this[profEncryptedKey] = secureStore.encrypt(value)
            remove(profLegacyKey)
        }
    }

    private fun MutablePreferences.migrateSecret(
        encryptedKey: Preferences.Key<String>,
        legacyKey: Preferences.Key<String>
    ) {
        val legacyValue = this[legacyKey]
        val encryptedValue = this[encryptedKey]
        if (!encryptedValue.isNullOrBlank()) {
            remove(legacyKey)
            return
        }
        if (!legacyValue.isNullOrBlank()) {
            runCatching {
                this[encryptedKey] = secureStore.encrypt(legacyValue)
                remove(legacyKey)
            }
        }
    }

    suspend fun exportConfigJson(
        includeTunnel: Boolean,
        includeDeploy: Boolean,
        includeExceptions: Boolean,
        includeSettings: Boolean
    ): String {
        val prefs = dataStore.data.first()
        // the ACTIVE profile's values (base keys are profile 0's), and secrets the way the store keeps them
        val p = prefs[ACTIVE_PROFILE] ?: 0
        val root = JSONObject()
        root.put("version", 1)
        root.put("exported_at", System.currentTimeMillis())

        if (includeTunnel) {
            val tunnel = JSONObject()
            tunnel.put("peer", prefs[getProfileKey(PEER, p)] ?: "")
            tunnel.put("listen_port", prefs[getProfileKey(LISTEN_PORT, p)] ?: MrttConstants.Network.DEFAULT_LOCAL_PORT)
            tunnel.put("manual_ports_enabled", prefs[getProfileKey(MANUAL_PORTS_ENABLED, p)] ?: false)
            tunnel.put("server_peer_port", prefs[getProfileKey(SERVER_PEER_PORT, p)] ?: MrttConstants.Network.DEFAULT_SERVER_PEER_PORT)
            tunnel.put("connection_password", readConnectionPasswordState(prefs, p).value)
            tunnel.put("obfs_mode", prefs[getProfileKey(OBFS_MODE, p)] ?: MrttConstants.Tunnel.DEFAULT_OBFS_MODE)
            tunnel.put("turn_transport", prefs[getProfileKey(TURN_TRANSPORT, p)] ?: MrttConstants.Tunnel.DEFAULT_TURN_TRANSPORT)
            tunnel.put("srtp_mode", prefs[getProfileKey(SRTP_MODE, p)] ?: MrttConstants.SrtpMode.DEFAULT)
            tunnel.put("custom_turn_ips", prefs[getProfileKey(CUSTOM_TURN_IPS, p)] ?: "")
            tunnel.put("sni", prefs[getProfileKey(SNI, p)] ?: "")
            tunnel.put("no_dns", prefs[getProfileKey(NO_DNS, p)] ?: false)
            root.put("tunnel", tunnel)
        }

        if (includeDeploy) {
            val deploy = JSONObject()
            deploy.put("deploy_ip", prefs[getProfileKey(DEPLOY_IP, p)] ?: "")
            deploy.put("deploy_login", prefs[getProfileKey(DEPLOY_LOGIN, p)] ?: "")
            deploy.put("deploy_ssh_port", prefs[getProfileKey(DEPLOY_SSH_PORT, p)] ?: "")
            deploy.put("server_web_port", prefs[getProfileKey(SERVER_WEB_PORT, p)] ?: MrttConstants.Network.DEFAULT_SERVER_WEB_PORT)
            deploy.put("docker_install", prefs[getProfileKey(DOCKER_INSTALL, p)] ?: true)
            deploy.put("ssh_keys_mode", prefs[getProfileKey(SSH_KEYS_MODE, p)] ?: false)
            deploy.put("vk_hashes", prefs[getProfileKey(VK_HASHES, p)] ?: "")
            deploy.put("secondary_vk_hash", prefs[getProfileKey(SECONDARY_VK_HASH, p)] ?: "")
            deploy.put("vk_auth_mode", prefs[getProfileKey(VK_AUTH_MODE, p)] ?: MrttConstants.VkAuth.MODE_CALLS)
            deploy.put("vk_hash_mode", prefs[getProfileKey(VK_HASH_MODE, p)] ?: MrttConstants.VkAutoHash.MODE_MANUAL)
            // the VK access token is a VK account credential: it stays on this device (an export goes to the clipboard
            // and Downloads). Older exports carried it blank in practice; the import below leaves a stored one alone.
            deploy.put("workers_per_hash", prefs[getProfileKey(WORKERS_PER_HASH, p)] ?: MrttConstants.Tunnel.DEFAULT_WORKERS)
            deploy.put("extra_workers", prefs[getProfileKey(EXTRA_WORKERS, p)] ?: false)
            deploy.put("mrtt_link", prefs[getProfileKey(MRTT_LINK, p)] ?: "")
            deploy.put("mrtt_link_mode", prefs[getProfileKey(MRTT_LINK_MODE, p)] ?: false)
            deploy.put("secret_path_enabled", prefs[getProfileKey(DEPLOY_SECRET_PATH_ENABLED, p)] ?: false)
            deploy.put("secret_path_uuid", prefs[getProfileKey(DEPLOY_SECRET_PATH_UUID, p)] ?: "")
            root.put("deploy", deploy)
        }

        if (includeExceptions) {
            val exc = JSONObject()
            exc.put("excluded_apps", prefs[getProfileKey(EXCLUDED_APPS, p)] ?: "")
            exc.put("whitelist_apps", prefs[getProfileKey(WHITELIST_APPS, p)] ?: "")
            exc.put("is_whitelist", prefs[getProfileKey(IS_WHITELIST, p)] ?: false)
            exc.put("domain_routing_enabled", prefs[getProfileKey(DOMAIN_ROUTING_ENABLED, p)] ?: false)
            exc.put("domain_is_whitelist", prefs[getProfileKey(DOMAIN_IS_WHITELIST, p)] ?: false)
            exc.put("exclude_ru_zones_enabled", prefs[getProfileKey(EXCLUDE_RU_ZONES_ENABLED, p)] ?: false)
            exc.put("template_domains_enabled", prefs[getProfileKey(TEMPLATE_DOMAINS_ENABLED, p)] ?: false)
            exc.put("adblock_enabled", prefs[getProfileKey(ADBLOCK_ENABLED, p)] ?: false)
            exc.put("adblock_domains", prefs[getProfileKey(ADBLOCK_DOMAINS, p)] ?: "")
            exc.put("adblock_subscriptions", prefs[getProfileKey(ADBLOCK_SUBSCRIPTIONS, p)] ?: "")
            exc.put("adblock_categories", prefs[getProfileKey(ADBLOCK_CATEGORIES, p)] ?: "")
            exc.put("geosite_ru_enabled", prefs[getProfileKey(GEOSITE_RU_ENABLED, p)] ?: false)
            exc.put("port_hide_root", prefs[PORT_HIDE_ROOT] ?: false)
            exc.put("port_hide_packages", prefs[PORT_HIDE_PACKAGES] ?: "")
            exc.put("game_mode_enabled", prefs[getProfileKey(GAME_MODE_ENABLED, p)] ?: false)
            exc.put("game_mode_auto", prefs[getProfileKey(GAME_MODE_AUTO, p)] ?: true)
            exc.put("game_packages", prefs[getProfileKey(GAME_PACKAGES, p)] ?: "")
            exc.put("game_extra_ports", prefs[getProfileKey(GAME_EXTRA_PORTS, p)] ?: "")
            exc.put("game_tunnel_packages", prefs[getProfileKey(GAME_TUNNEL_PACKAGES, p)] ?: "")
            exc.put("direct_domains_black", prefs[getProfileKey(DIRECT_DOMAINS_BLACK, p)] ?: prefs[getProfileKey(DIRECT_DOMAINS, p)] ?: "")
            exc.put("direct_domains_white", prefs[getProfileKey(DIRECT_DOMAINS_WHITE, p)] ?: "")
            exc.put("ip_routing_enabled", prefs[getProfileKey(IP_ROUTING_ENABLED, p)] ?: false)
            exc.put("ip_is_whitelist", prefs[getProfileKey(IP_IS_WHITELIST, p)] ?: false)
            exc.put("direct_ips_black", prefs[getProfileKey(DIRECT_IPS_BLACK, p)] ?: "")
            exc.put("direct_ips_white", prefs[getProfileKey(DIRECT_IPS_WHITE, p)] ?: "")
            root.put("exceptions", exc)
        }

        if (includeSettings) {
            val settings = JSONObject()
            settings.put("theme_mode", prefs[THEME_MODE] ?: "system")
            settings.put("is_dynamic_color", prefs[IS_DYNAMIC_COLOR] ?: false)
            settings.put("theme_palette", prefs[THEME_PALETTE] ?: "classic")
            settings.put("auto_pause_on_wifi", prefs[AUTO_PAUSE_ON_WIFI] ?: false)
            settings.put("auto_connect_on_launch", prefs[AUTO_CONNECT_ON_LAUNCH] ?: false)
            settings.put("battery_saver_mode", prefs[BATTERY_SAVER_MODE] ?: BatterySaver.DEFAULT_MODE)
            settings.put("battery_saver_percent", prefs[BATTERY_SAVER_PERCENT] ?: BatterySaver.DEFAULT_PERCENT)
            settings.put("selected_fingerprint", prefs[getProfileKey(SELECTED_FINGERPRINT, p)] ?: "chrome")
            settings.put("selected_turn_subnet", prefs[getProfileKey(SELECTED_TURN_SUBNET, p)] ?: "")
            settings.put("turn_subnet_ip_limit", prefs[getProfileKey(TURN_SUBNET_IP_LIMIT, p)] ?: "ALL")
            settings.put("logging_enabled", prefs[LOGGING_ENABLED] ?: true)
            settings.put("detailed_logs", prefs[DETAILED_LOGS] ?: false)
            settings.put("participant_show_logs", prefs[getProfileKey(PARTICIPANT_SHOW_LOGS, p)] ?: false)
            root.put("settings", settings)
        }

        return root.toString(2)
    }

    suspend fun importConfigJson(
        jsonString: String,
        includeTunnel: Boolean,
        includeDeploy: Boolean,
        includeExceptions: Boolean,
        includeSettings: Boolean
    ): Boolean {
        return runCatching {
            val root = JSONObject(jsonString)
            dataStore.edit { mutable ->
                // into the ACTIVE profile (base keys are profile 0's), secrets the way the store keeps them
                val p = mutable[ACTIVE_PROFILE] ?: 0
                if (includeTunnel && root.has("tunnel")) {
                    val tunnel = root.getJSONObject("tunnel")
                    if (tunnel.has("peer")) mutable[getProfileKey(PEER, p)] = tunnel.getString("peer")
                    if (tunnel.has("listen_port")) mutable[getProfileKey(LISTEN_PORT, p)] = tunnel.getInt("listen_port")
                    if (tunnel.has("manual_ports_enabled")) mutable[getProfileKey(MANUAL_PORTS_ENABLED, p)] = tunnel.getBoolean("manual_ports_enabled")
                    if (tunnel.has("server_peer_port")) mutable[getProfileKey(SERVER_PEER_PORT, p)] = tunnel.getInt("server_peer_port")
                    // a blank password in an export is "none in that export" (older exports carried a stored one blank):
                    // it never wipes the password this profile has
                    val pw = if (tunnel.has("connection_password")) tunnel.getString("connection_password") else ""
                    if (pw.isNotBlank()) {
                        // as saveConnectionPassword stores it
                        mutable[getProfileKey(CONNECTION_PASSWORD_LOCAL, p)] = pw
                        mutable.remove(getProfileKey(CONNECTION_PASSWORD, p))
                        mutable.remove(getProfileKey(CONNECTION_PASSWORD_ENCRYPTED, p))
                    }
                    if (tunnel.has("obfs_mode")) mutable[getProfileKey(OBFS_MODE, p)] = tunnel.getString("obfs_mode")
                    if (tunnel.has("turn_transport")) mutable[getProfileKey(TURN_TRANSPORT, p)] = tunnel.getString("turn_transport")
                    if (tunnel.has("srtp_mode")) mutable[getProfileKey(SRTP_MODE, p)] = tunnel.getString("srtp_mode")
                    if (tunnel.has("custom_turn_ips")) mutable[getProfileKey(CUSTOM_TURN_IPS, p)] = tunnel.getString("custom_turn_ips")
                    if (tunnel.has("sni")) mutable[getProfileKey(SNI, p)] = tunnel.getString("sni")
                    if (tunnel.has("no_dns")) mutable[getProfileKey(NO_DNS, p)] = tunnel.getBoolean("no_dns")
                }
                if (includeDeploy && root.has("deploy")) {
                    val deploy = root.getJSONObject("deploy")
                    if (deploy.has("deploy_ip")) mutable[getProfileKey(DEPLOY_IP, p)] = deploy.getString("deploy_ip")
                    if (deploy.has("deploy_login")) mutable[getProfileKey(DEPLOY_LOGIN, p)] = deploy.getString("deploy_login")
                    if (deploy.has("deploy_ssh_port")) mutable[getProfileKey(DEPLOY_SSH_PORT, p)] = deploy.getString("deploy_ssh_port")
                    if (deploy.has("server_web_port")) mutable[getProfileKey(SERVER_WEB_PORT, p)] = deploy.getInt("server_web_port")
                    if (deploy.has("docker_install")) mutable[getProfileKey(DOCKER_INSTALL, p)] = deploy.getBoolean("docker_install")
                    if (deploy.has("ssh_keys_mode")) mutable[getProfileKey(SSH_KEYS_MODE, p)] = deploy.getBoolean("ssh_keys_mode")
                    if (deploy.has("vk_hashes")) mutable[getProfileKey(VK_HASHES, p)] = deploy.getString("vk_hashes")
                    if (deploy.has("secondary_vk_hash")) mutable[getProfileKey(SECONDARY_VK_HASH, p)] = deploy.getString("secondary_vk_hash")
                    if (deploy.has("vk_auth_mode")) mutable[getProfileKey(VK_AUTH_MODE, p)] = deploy.getString("vk_auth_mode")
                    if (deploy.has("vk_hash_mode")) mutable[getProfileKey(VK_HASH_MODE, p)] = deploy.getString("vk_hash_mode")
                    // blank (every older export) leaves the stored token alone; exports no longer carry it
                    deploy.optString("vk_access_token").takeIf { it.isNotBlank() }?.let {
                        mutable.putSecret(VK_ACCESS_TOKEN_ENCRYPTED, VK_ACCESS_TOKEN, it, p)
                    }
                    if (deploy.has("workers_per_hash")) mutable[getProfileKey(WORKERS_PER_HASH, p)] = deploy.getInt("workers_per_hash")
                    if (deploy.has("extra_workers")) mutable[getProfileKey(EXTRA_WORKERS, p)] = deploy.getBoolean("extra_workers")
                    if (deploy.has("mrtt_link")) mutable[getProfileKey(MRTT_LINK, p)] = deploy.getString("mrtt_link")
                    if (deploy.has("mrtt_link_mode")) mutable[getProfileKey(MRTT_LINK_MODE, p)] = deploy.getBoolean("mrtt_link_mode")
                    if (deploy.has("secret_path_enabled")) mutable[getProfileKey(DEPLOY_SECRET_PATH_ENABLED, p)] = deploy.getBoolean("secret_path_enabled")
                    if (deploy.has("secret_path_uuid")) mutable[getProfileKey(DEPLOY_SECRET_PATH_UUID, p)] = deploy.getString("secret_path_uuid")
                }
                if (includeExceptions && root.has("exceptions")) {
                    val exc = root.getJSONObject("exceptions")
                    if (exc.has("excluded_apps")) mutable[getProfileKey(EXCLUDED_APPS, p)] = exc.getString("excluded_apps")
                    if (exc.has("whitelist_apps")) mutable[getProfileKey(WHITELIST_APPS, p)] = exc.getString("whitelist_apps")
                    if (exc.has("is_whitelist")) mutable[getProfileKey(IS_WHITELIST, p)] = exc.getBoolean("is_whitelist")
                    if (exc.has("domain_routing_enabled")) mutable[getProfileKey(DOMAIN_ROUTING_ENABLED, p)] = exc.getBoolean("domain_routing_enabled")
                    if (exc.has("adblock_enabled")) mutable[getProfileKey(ADBLOCK_ENABLED, p)] = exc.getBoolean("adblock_enabled")
                    if (exc.has("adblock_domains")) mutable[getProfileKey(ADBLOCK_DOMAINS, p)] = exc.getString("adblock_domains")
                    if (exc.has("adblock_subscriptions")) mutable[getProfileKey(ADBLOCK_SUBSCRIPTIONS, p)] = exc.getString("adblock_subscriptions")
                    if (exc.has("adblock_categories")) mutable[getProfileKey(ADBLOCK_CATEGORIES, p)] = exc.getString("adblock_categories")
                    if (exc.has("geosite_ru_enabled")) mutable[getProfileKey(GEOSITE_RU_ENABLED, p)] = exc.getBoolean("geosite_ru_enabled")
                    if (exc.has("port_hide_root")) mutable[PORT_HIDE_ROOT] = exc.getBoolean("port_hide_root")
                    if (exc.has("port_hide_packages")) mutable[PORT_HIDE_PACKAGES] = exc.getString("port_hide_packages")
                    if (exc.has("game_mode_enabled")) mutable[getProfileKey(GAME_MODE_ENABLED, p)] = exc.getBoolean("game_mode_enabled")
                    if (exc.has("game_mode_auto")) mutable[getProfileKey(GAME_MODE_AUTO, p)] = exc.getBoolean("game_mode_auto")
                    if (exc.has("game_packages")) mutable[getProfileKey(GAME_PACKAGES, p)] = exc.getString("game_packages")
                    if (exc.has("game_extra_ports")) mutable[getProfileKey(GAME_EXTRA_PORTS, p)] = exc.getString("game_extra_ports")
                    if (exc.has("game_tunnel_packages")) mutable[getProfileKey(GAME_TUNNEL_PACKAGES, p)] = exc.getString("game_tunnel_packages")
                    if (exc.has("domain_is_whitelist")) mutable[getProfileKey(DOMAIN_IS_WHITELIST, p)] = exc.getBoolean("domain_is_whitelist")
                    if (exc.has("exclude_ru_zones_enabled")) mutable[getProfileKey(EXCLUDE_RU_ZONES_ENABLED, p)] = exc.getBoolean("exclude_ru_zones_enabled")
                    if (exc.has("template_domains_enabled")) mutable[getProfileKey(TEMPLATE_DOMAINS_ENABLED, p)] = exc.getBoolean("template_domains_enabled")
                    if (exc.has("direct_domains_black")) mutable[getProfileKey(DIRECT_DOMAINS_BLACK, p)] = exc.getString("direct_domains_black")
                    if (exc.has("direct_domains_white")) mutable[getProfileKey(DIRECT_DOMAINS_WHITE, p)] = exc.getString("direct_domains_white")
                    if (exc.has("ip_routing_enabled")) mutable[getProfileKey(IP_ROUTING_ENABLED, p)] = exc.getBoolean("ip_routing_enabled")
                    if (exc.has("ip_is_whitelist")) mutable[getProfileKey(IP_IS_WHITELIST, p)] = exc.getBoolean("ip_is_whitelist")
                    if (exc.has("direct_ips_black")) mutable[getProfileKey(DIRECT_IPS_BLACK, p)] = exc.getString("direct_ips_black")
                    if (exc.has("direct_ips_white")) mutable[getProfileKey(DIRECT_IPS_WHITE, p)] = exc.getString("direct_ips_white")
                }
                if (includeSettings && root.has("settings")) {
                    val s = root.getJSONObject("settings")
                    if (s.has("theme_mode")) mutable[THEME_MODE] = s.getString("theme_mode")
                    if (s.has("is_dynamic_color")) mutable[IS_DYNAMIC_COLOR] = s.getBoolean("is_dynamic_color")
                    if (s.has("theme_palette")) mutable[THEME_PALETTE] = s.getString("theme_palette")
                    if (s.has("auto_pause_on_wifi")) mutable[AUTO_PAUSE_ON_WIFI] = s.getBoolean("auto_pause_on_wifi")
                    if (s.has("auto_connect_on_launch")) mutable[AUTO_CONNECT_ON_LAUNCH] = s.getBoolean("auto_connect_on_launch")
                    // an unknown mode (a newer or edited export) leaves the stored one: the UI could show it only as «Авто»
                    s.optString("battery_saver_mode").takeIf { mode -> BatterySaver.MODES.any { it.first == mode } }
                        ?.let { mutable[BATTERY_SAVER_MODE] = it }
                    if (s.has("battery_saver_percent")) mutable[BATTERY_SAVER_PERCENT] = s.getInt("battery_saver_percent").coerceIn(5, 95)
                    if (s.has("selected_fingerprint")) mutable[getProfileKey(SELECTED_FINGERPRINT, p)] = s.getString("selected_fingerprint")
                    if (s.has("selected_turn_subnet")) mutable[getProfileKey(SELECTED_TURN_SUBNET, p)] = s.getString("selected_turn_subnet")
                    if (s.has("turn_subnet_ip_limit")) mutable[getProfileKey(TURN_SUBNET_IP_LIMIT, p)] = s.getString("turn_subnet_ip_limit")
                    if (s.has("logging_enabled")) mutable[LOGGING_ENABLED] = s.getBoolean("logging_enabled")
                    if (s.has("detailed_logs")) mutable[DETAILED_LOGS] = s.getBoolean("detailed_logs")
                    val currentProfile = mutable[ACTIVE_PROFILE] ?: 0
                    if (s.has("participant_show_logs")) mutable[getProfileKey(PARTICIPANT_SHOW_LOGS, currentProfile)] = s.getBoolean("participant_show_logs")
                }
            }
            true
        }.getOrDefault(false)
    }

    // Start observers only after every settings Flow has been initialized.
    init {
        if (migrationsStarted.compareAndSet(false, true)) {
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                migrateConnectionPasswordsToLocalStorage()
                migrateSecretsToKeystore()
                migrateLegacyWhitelistMode()
            }
        }
        if (uiCacheStarted.compareAndSet(false, true)) {
            CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
                launch {
                    dataStore.edit { prefs ->
                        for (p in MrttConstants.Profiles.MIN_INDEX..MrttConstants.Profiles.MAX_INDEX) {
                            prefs[getProfileKey(EXTRA_WORKERS, p)] = false
                        }
                    }
                }
                launch { vkHashMode.collect { cachedVkHashMode = it } }
                launch { vkSession.collect { cachedVkSession = it } }
                // Вход через приложение ВК: тот же кэш, чтобы проверка привязки
                // не ходила в DataStore на каждом запуске.
                launch { vkIdToken.collect { cachedVkIdToken = it } }
                launch { obfsMode.collect { cachedObfsMode = it } }
                launch { hideTunnelFingerprint.collect { cachedHideTunnelFingerprint = it } }
                launch { turnTransport.collect { cachedTurnTransport = it } }
                launch { srtpMode.collect { cachedSrtpMode = it } }
                launch { mrttLinkMode.collect { cachedMrttLinkMode = it } }
                launch { workersPerHash.collect { cachedWorkersPerHash = it } }
                launch { manualPortsEnabled.collect { cachedManualPortsEnabled = it } }
                launch { serverPeerPort.collect { cachedServerPeerPort = it } }
                cachedExtraWorkers = false
                launch { customTurnIps.collect { cachedCustomTurnIps = it } }
                launch { excludedApps.collect { cachedExcludedApps = it } }
                launch { whitelistApps.collect { cachedWhitelistApps = it } }
                launch { appDirectFiltered.collect { cachedAppDirectFiltered = it } }
                launch { appDirectRaw.collect { cachedAppDirectRaw = it } }
                launch { isWhitelist.collect { cachedIsWhitelist = it } }
                launch { domainRoutingEnabled.collect { cachedDomainRoutingEnabled = it } }
                launch { domainIsWhitelist.collect { cachedDomainIsWhitelist = it } }
                launch { excludeRuZonesEnabled.collect { cachedExcludeRuZonesEnabled = it } }
                launch { templateDomainsEnabled.collect { cachedTemplateDomainsEnabled = it } }
                launch { directDomains.collect { cachedDirectDomains = it } }
                launch { directDomainsBlack.collect { cachedDirectDomainsBlack = it } }
                launch { directDomainsWhite.collect { cachedDirectDomainsWhite = it } }
                launch { ipRoutingEnabled.collect { cachedIpRoutingEnabled = it } }
                launch { ipIsWhitelist.collect { cachedIpIsWhitelist = it } }
                launch { directIpsBlack.collect { cachedDirectIpsBlack = it } }
                launch { directIpsWhite.collect { cachedDirectIpsWhite = it } }
                launch { gameModeEnabled.collect { cachedGameModeEnabled = it } }
                launch { gameModeAuto.collect { cachedGameModeAuto = it } }
                launch { ownServerIps.collect { cachedOwnServerIps = it } }
                launch { mrttLink.collect { cachedLinkVkToken = linkVkTokenOf(it) } }
            }
        }
    }
}

/**
 * VK-токен из ссылки активного профиля — «аккаунт сервера». Пустая строка,
 * если ссылки нет или в ней нет токена.
 */
internal fun linkVkTokenOf(link: String): String =
    if (link.isBlank()) "" else runCatching { parseMrttLink(link)?.vkAccessToken.orEmpty() }.getOrDefault("")

internal fun clampJitsiWorkers(workers: Int): Int =
    workers.coerceIn(MrttConstants.Tunnel.MIN_JITSI_WORKERS, MrttConstants.Tunnel.MAX_JITSI_WORKERS)
